#
# WARNING: NEVER EDIT ET_Config.pm. Instead, copy any sections you want to change to ET_SiteConfig.pm
# and edit them there.
#

package RTx::EventTracker;

=head1 NAME

ET::Config

=for testing

use ET::Config;

=cut

# $DefaultSearchResultFormat is the default format for RT search results
Set ($DefaultSearchResultFormat, 
 qq{'<B><A HREF="$RT::WebPath/AssetTracker/Asset/Display.html?id=__id__">__Source__</a></B>/TITLE:Source',
   Message,
   Created,
   TypeName, 
   }
   );


# Event name uniqueness is now enforced by the API instead of the DB
# The rules are evaluated in this order:
Set ($GlobalUniqueEventName, 0);
Set ($TypeUniqueEventName, 0);
Set ($TypeStatusUniqueEventName, 0);

# The number of history items to display on the Event main page
# (set to 0 to turn  off)
Set ($ShowEventHistory, 50);

# When displaying event watchers descend into groups and show
# the user members. Turning this off make the display more succinct.
Set ($ShowGroupMembers, 1);

# If you turn this on not only will the event display
# show watchers directly assigned to the event, but type 
# watchers will also display. This may clear up confusion 
# where users think there is no watcher assigned when there really is.
Set ($ShowTypeWatchersInEvent, 0);

1;
