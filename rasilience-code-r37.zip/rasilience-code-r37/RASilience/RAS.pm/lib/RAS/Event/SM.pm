#-------- RAS::Event::SM Object --------##  -*- cperl -*-
package RAS::Event::SM;

require Exporter;
@RAS::Event::SM::ISA= qw(RAS::Event);
@EXPORT = qw(&new
	    );

use strict;
use warnings;

sub new {
# Desc: RAS::Event::SM object constructor
# Input: 1) $ I  Event message
# Returns: $  blessed object
#          undef: on error
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my $self = {};
  bless($self, $class);

  if (@_) {
    my $msg = shift;
    if ($msg =~ m|^
               (\d+/\d+/\d+\s+\d+:\d+:\d+)      # date
               \s+
               (\S+)                          # guid
               \s+
	       --
               \s+
               (.*)                           # source
               \s+
	       --
               \s+
               (.*)                           # message
               $|ox) {
      my ($date, $guid, $source, $message) = ($1, $2, $3, $4);
      $self = $self->SUPER::new('SM');
      if ($source eq 'unknown') {
	$source = $guid;
      }
      $self->date($date);
      $self->source($source);
      $self->message($message);
    }
    else {
      print STDERR "Warning: line not in SM grokker format: $msg\n";
      return undef;
    }
  }

  return $self;
}

1;
