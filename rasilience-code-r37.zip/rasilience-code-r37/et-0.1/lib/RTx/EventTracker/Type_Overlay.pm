=head1 NAME

  RTx::EventTracker::Type - an EventTracker Type object

=head1 SYNOPSIS

  use RTx::EventTracker::Type;

=head1 DESCRIPTION


=head1 METHODS

=begin testing 

use RTx::EventTracker::Type;

=end testing

=cut


package RTx::EventTracker::Type;

use strict;
no warnings qw(redefine);

use RT::CustomField;
use RT::CustomFields;
use RT::Group;

# {{{ sub Create




=head2 Create

Create takes the name of the new type
If you pass the ACL check, it creates the type and returns its type id.

=begin testing

my $type = RTx::EventTracker::Type->new($RT::SystemUser);
my ($id, $val) = $type->Create( Name => 'Test1');
ok($id, $val);

($id, $val) = $type->Create( Name => '66');
ok(!$id, $val);


=end testing


=cut

sub Create {
    my $self = shift;
    my %args = (
        Name              => undef,
        Description       => '',
        Disabled          => 0,
        @_
    );

    $RT::Handle->BeginTransaction();

    my $id = $self->SUPER::Create(%args);
    unless ($id) {
        $RT::Handle->Rollback();
        return ( 0, $self->loc('Event type could not be created') );
    }

    $RT::Handle->Commit();
    return ( $id, $self->loc("Event type created") );
}

# }}}

# {{{ sub Load

=head2 Load

Takes either a numerical id or a textual Name and loads the specified type.

=cut

sub Load {
    my $self = shift;

    my $identifier = shift;
    if ( !$identifier ) {
        return (undef);
    }

    if ( $identifier =~ /^(\d+)$/ ) {
        my ($ret, $msg) = $self->SUPER::LoadById($identifier);
	if (!$ret) {
	    return undef;
	}
    }
    else {
        my ($ret, $msg) = $self->LoadByCols( Name => $identifier );
	if (!$ret) {
	    return undef;
	}
    }

    return ( $self->Id );
}

# }}}

# {{{ sub Delete

sub Delete {
    my $self = shift;
    # TODO: Do something valid here
#    return ( 0,
#        $self->loc('Deleting this object would break referential integrity') );
}

# }}}

# {{{  CustomField

=item CustomField NAME

Load the type-specific custom field named NAME

=cut

sub CustomField {
    my $self = shift;
    my $name = shift;
    my $cf = RT::CustomField->new($self->CurrentUser);
    $cf->LoadByName(Name => $name, Type => $self->Id);
    return ($cf);
}

# }}}

sub EventCustomFields {
    my $self = shift;

    my $cfs = RT::CustomFields->new( $self->CurrentUser );
#    if ( $self->CurrentUserHasRight('SeeType') ) {
        $cfs->LimitToGlobalOrObjectId( $self->Id );
        $cfs->LimitToLookupType( 'RTx::EventTracker::Type-RTx::EventTracker::Event' );
 #   }
    return ($cfs);
}

# {{{ sub CurrentUserHasRight

=head2 CurrentUserHasRight

Takes one argument. A textual string with the name of the right we want to check.
Returns true if the current user has that right for this type.
Returns undef otherwise.

=cut

sub CurrentUserHasRight {
    my $self  = shift;
    my $right = shift;

    return (
        $self->HasRight(
            Principal => $self->CurrentUser,
            Right     => "$right",
            EquivObjects => [$RTx::AssetTracker::System],
          )
    );

}

# }}}

# {{{ sub HasRight

=head2 HasRight

Takes a param hash with the fields 'Right' and 'Principal'.
Principal defaults to the current user.
Returns true if the principal has that right for this type.
Returns undef otherwise.

=cut

# TAKES: Right and optional "Principal" which defaults to the current user
sub HasRight {
    my $self = shift;
    my %args = (
        Right     => undef,
        Principal => $self->CurrentUser,
        @_
    );
    unless ( defined $args{'Principal'} ) {
        $RT::Logger->debug("Principal undefined in Type::HasRight");

    }
    return (
        $args{'Principal'}->HasRight(
            Object => $self->Id ? $self : $RTx::AssetTracker::System,
            Right    => $args{'Right'},
            @_
          )
    );
}

# }}}




1;
