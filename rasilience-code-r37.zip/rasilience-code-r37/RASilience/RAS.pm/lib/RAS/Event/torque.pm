#-------- RAS::Event::torque Object --------## -*- cperl -*-
package RAS::Event::torque;
use strict;
use warnings;

require Exporter;
@RAS::Event::torque::ISA = qw(RAS::Event);
@EXPORT = qw(&new
	    );

sub new {
# Desc: RAS::Event::torque object constructor
# Input: 1) $ I?  Optional torque message
# Returns: $  blessed object
#          undef: on error
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my $self = {};
  bless($self, $class);

  if (@_) {
    my @nodelist = ();        # filled in based on "exec_host"
    my %torque_cfs = qw( 
                            account                     1
                            exec_host                   1
                            Exit_status                 1
                            jobname                     1
                            queue                       1
                            requestor                   1
                            Resource_List.nodect        1
                            Resource_List.nodes         1
                            Resource_List.walltime      1
                            resources_used.cput         1
                            resources_used.mem          1
                            resources_used.vmem         1
                            resources_used.walltime     1
                            user                        1
                       );
    my $msg = shift;
    if ($msg =~ /^
               (\d{2}\/\d{2}\/\d{4}\s+\d+:\d+:\d+)  # date & time
               ;
               (\S)                                 # message type
               ;
               (\d+)\.(\S+)                         # job ID
               ;
               (.*)                                 # key|value pairs
               $/ox) {
      my ($date, $type, $jobid, $server, $key_value) = ($1, $2, $3, $4, $5);
      $self = $self->SUPER::new('torque');
      $self->source($server);

      if ( $type eq "Q" ) {
        $self->message("Job $jobid Queued");
      } elsif ( $type eq "S" ) {
        $self->message("Job $jobid Started");
      } elsif ( $type eq "E" ) {
        $self->message("Job $jobid Exited");
      } elsif ( $type eq "D" ) {
        $self->message("Job $jobid Deleted");
      } else {
        $self->message("Job $jobid event type '$type'");
      }

      #
      # Set up torque custom fields 
      #
      $self->custom_field_value('jobid', $jobid);

      for my $pair ( split /\s+/, $key_value ) {
        if ( $pair !~ /^(\S+)=(\S+)$/ ) {
          print STDERR "Warning: line not in torque format (bad key/value): $msg";
          return undef;
        }

        # Parse all Torque key=value pairs and populate custom field values
	# (see %torque_cfs for field list)
        my ($key, $value) = ($1, $2);
        if ( $key eq "exec_host" ) {
          my %seen_nodes = ();
          for my $node ( split /\+/, $value ) {
            $node =~ s/\/\d+//;
            push @nodelist, $node unless exists $seen_nodes{$node};
            $seen_nodes{$node}++;
          }
          $self->custom_field_value('nodelist', join(',', @nodelist) . ',');
        }
        elsif ( exists $torque_cfs{$key} ) {
          $self->custom_field_value($key, $value);
        }
      }

    }
    else {
      print STDERR "Warning: line not in torque format: $msg";
      return undef;
    }
  }

  return $self;
}

1;
