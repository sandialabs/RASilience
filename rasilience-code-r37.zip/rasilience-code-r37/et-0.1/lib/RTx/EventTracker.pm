# BEGIN LICENSE BLOCK
# 
#  Copyright (c) 2002-2003 Jesse Vincent <jesse@bestpractical.com>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of version 2 of the GNU General Public License 
#  as published by the Free Software Foundation.
# 
#  A copy of that license should have arrived with this
#  software, but in any event can be snarfed from www.gnu.org.
# 
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
# 
# END LICENSE BLOCK

package RTx::EventTracker;
use strict;
use RTx::EventTracker::Type;
use RTx::EventTracker::Event;

use vars qw($VERSION
        $CORE_CONFIG_FILE
        $SITE_CONFIG_FILE
	$EtcPath
	$VarPath
	$LocalPath
	$LocalEtcPath
	$LocalLexiconPath
        $ETConfigDone
);

$VERSION = '0.1.0';
$CORE_CONFIG_FILE = "/opt/rt3/local/etc/EventTracker/ET_Config.pm";
$SITE_CONFIG_FILE = "/opt/rt3/local/etc/EventTracker/ET_SiteConfig.pm";
$ETConfigDone = 0;



#$BasePath = '';

#$EtcPath = '';
#$BinPath = '';
#$VarPath = '';
#$LocalPath = '';
$LocalEtcPath = "/opt/rt3/local/etc/EventTracker";
#$LocalLexiconPath = '';



=head2 LoadConfig

Load ET's config file. First, go after the core config file.
After that, go after the site config.

=cut

sub LoadConfig {
    local *Set = sub { $_[0] = $_[1] unless defined $_[0] };
    if ( -f "$SITE_CONFIG_FILE" ) {
        require $SITE_CONFIG_FILE
          || die ("Couldn't load ET config file  '$SITE_CONFIG_FILE'\n$@");
    }
    require $CORE_CONFIG_FILE
      || die ("Couldn't load ET config file '$CORE_CONFIG_FILE'\n$@");

    RT->Init();
    $ETConfigDone = 1;
}


1;
