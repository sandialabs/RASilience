=head1 NAME

  RTx::EventTracker::Types - a collection of EventTracker Types objects

=head1 SYNOPSIS

  use RTx::EventTracker::Types;

=head1 DESCRIPTION


=head1 METHODS

=begin testing 

ok (require RTx::EventTracker::Types);

=end testing

=cut


package RTx::EventTracker::Types;

use strict;
no warnings qw(redefine);


# {{{ sub _DoSearch

=head2 _DoSearch

  A subclass of DBIx::SearchBuilder::_DoSearch that makes sure that _Disabled rows never get seen unless
we're explicitly trying to see them.

=cut

sub _DoSearch {
    my $self = shift;

    # bMake sure we're only finding enabled rows unless we really want to find disabled rows
    unless($self->{'find_disabled_rows'}) {
        $self->LimitToEnabled();
    }

    return($self->SUPER::_DoSearch(@_));

}

# }}}


# {{{ sub Limit
sub Limit  {
  my $self = shift;
  my %args = ( ENTRYAGGREGATOR => 'AND',
               @_);
  $self->SUPER::Limit(%args);
}
# }}}

1;
