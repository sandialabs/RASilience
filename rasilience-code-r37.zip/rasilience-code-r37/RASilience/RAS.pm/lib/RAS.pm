# RASilience perl module             -*- cperl -*-
# Author: Josh England <jjengla@sandia.gov>
# This file contains many functions and classes common to all RASilience
# scripts.
#
# Copyright (2006) Josh England, Sandia Corporation.
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation,
# the U.S. Government retains certain rights in this software
#
#    This file is part of RASilience (http://rasilience.sourceforge.net).
#
#    RASilience is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    any later version.
#
#    RASilience is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with RASilience; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
###############################################################################

our (@ISA, @EXPORT);
our $VERSION = '0.1';

package RAS;
use strict;
use warnings;

require Exporter;
@EXPORT = qw($debug
             $verbose
);

# Some global variables
our $debug = 0;
our $verbose = 0;
our $quiet = 0;
our $RT_initialized = 0;

# RAS->init_RT() method
sub init_RT {
# Desc: Initialize RT for any component that needs to use it
# Input: None
# Returns: undef: on error
  my $self = shift;

  unless ($RT_initialized) {
    use lib '/opt/rt3/lib';
    use lib '/opt/rt3/local/lib';
    require Data::Dumper;	     #### for debug
    local $Data::Dumper::Deepcopy = 1; ##############

    # Try to load all required modules
    foreach my $module (qw(RT RT::Ticket RTx::AssetTracker RTx::AssetTracker::Asset
			   RTx::AssetTracker::Asset RTx::EventTracker::Event
			   RTx::EventTracker::Type)) {
      if (! eval "require $module") {
	print STDERR "\nError! This script requires the $module module.\n";
	print STDERR    "* * *  Add your RT library path to Perl's \@INC and try again.\n";
	die    "* * *  ie: run 'perl -I /path/to/rt3/lib ...', or modify PERL5LIB.\n";
      }
    }
    require RT;
    require RT::Ticket;
    require RTx::AssetTracker;
    require RTx::AssetTracker::Asset;
    require RTx::AssetTracker::Type;
    require RTx::EventTracker::Event;
    require RTx::EventTracker::Type;

    # Initialize RT/AT
    RT::LoadConfig();
    RTx::AssetTracker::LoadConfig();
    RT::Init();
    $RT_initialized = 1;
  }
}


#-------- RAS::Asset Object --------##

package RAS::Asset;
use strict;
use warnings;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
	     &asset
	     &name
             &description
             &type
             &status
             &add_ip_interface
             &get_ip_interface
             &get_all_ip_interfaces
             &custom_field_value
             &get_all_custom_fields
             &create
             &load
             &unload
	    );

sub new {
# Desc: RAS::Asset object constructor
# Input: 1) $ I  Asset name
# Returns: $  blessed object, empty
#          undef: on error
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my $self = {};
  bless($self, $class);

  if ($#_ != 0) {
    return undef;
  }
  my ($name) = @_;

  $self->{NAME} = undef;
  $self->{DESC} = undef;
  $self->{TYPE} = undef;
  $self->{STATUS} = undef;
  $self->{IP_INTERFACES} = [];
  $self->{CF_VALS} = {};
  $self->{ASSET} = undef;

  $self->name($name);

  return $self;
}

# RAS::Asset->asset() method
sub asset {
# Desc: Gets or sets the AT::Asset object
# Input: 1) $ I?  Optional AT::Asset object
# Returns: $  AT::Asset object
  my $self = shift;
  if (@_) {
    $self->{ASSET} = shift;
  }
  return $self->{ASSET};
}

# RAS::Asset->name() method
sub name {
# Desc: Gets or sets Asset name
# Input: 1) $ I?  Optional asset name
# Returns: $  asset name
#          undef: on error
  my $self = shift;
  my ($name) = @_;

  my $asset = $self->asset();
  if (defined $asset) {
    if (defined $name) {
      my ($ret, $msg) = $asset->SetName( Value => $name);
      if (!$ret) {
	print STDERR "Error setting name for ", $self->name(), ": $msg\n";
	return undef;
      }
    }
    else {
      $name = $asset->Name();
    }
  }
  else {
    if (defined $name) {
      $self->{NAME} = $name;
    }
    else {
      $name = $self->{NAME};
    }
  }
  return $name;
}


# RAS::Asset->get_id() method
sub get_id {
# Desc: Gets Asset ID from AT
# Input: 1) $ I  asset name
# Returns: $  asset ID
#          undef: on error
  my $self = shift;
  my ($name) = @_;
  my $id = undef;

  # Initialize RT
  RAS->init_RT();

  # Allow this method to be called directly
  unless (UNIVERSAL::isa($self, "RAS::Asset")) {
    $name = $self;
  }

  # Load AT asset -- turn off RT logging for a sec
  my $asset = RTx::AssetTracker::Asset->new($RT::SystemUser);
  my $logger = $RT::Logger;
  $RT::Logger = '';
  my $ret = eval { $asset->Load($name); };
  if (defined $ret) {
    $id = $asset->Id();
  }
  else {
#    print STDERR "Error: Asset not found: ", $name, "\n";
  }
  $RT::Logger = $logger;
  return $id;
}


# RAS::Asset->description() method
sub description {
# Desc: Gets or sets Asset description
# Input: 1) $ I?  Optional asset description
# Returns: $  asset description
#          undef: on error
  my $self = shift;
  my ($desc) = @_;

  my $asset = $self->asset();
  if (defined $asset) {
    if (defined $desc) {
      my ($ret, $msg) = $asset->SetDescription( Value => $desc);
      if (!$ret) {
	print STDERR "Error setting description for ", $self->name(), ": $msg\n";
	return undef;
      }
    }
    else {
      $desc = $asset->Description();
    }
  }
  else {
    if (defined $desc) {
      $self->{DESC} = $desc;
    }
    else {
      $desc = $self->{DESC};
    }
  }
  return $desc;
}

# RAS::Asset->type() method
sub type {
# Desc: Gets or sets Asset type
# Input: 1) $ I?  Optional asset type
# Returns: $  asset type
#          undef: on error
  my $self = shift;
  my ($type) = @_;

  my $asset = $self->asset();
  if (defined $asset) {
    if (defined $type) {
      my ($ret, $msg) = $asset->SetType( Value => $type);
      if (!$ret) {
	print STDERR "Error setting type for ", $self->name(), ": $msg\n";
	return undef;
      }
    }
    else {
      $type = $asset->Type();
    }
  }
  else {
    if (defined $type) {
      $self->{TYPE} = $type;
    }
    else {
      $type = $self->{TYPE};
    }
  }
  return $type;
}

# RAS::Asset->status() method
sub status {
# Desc: Gets or sets Asset status
# Input: 1) $ I?  Optional asset status
# Returns: $  asset status
#          undef: on error
  my $self = shift;
  my ($status) = @_;

  my $asset = $self->asset();
  if (defined $asset) {
    if (defined $status) {
      my ($ret, $msg) = $asset->SetStatus( Value => $status);
      if (!$ret) {
	print STDERR "Error setting status for ", $self->name(), ": $msg\n";
	return undef;
      }
    }
    else {
      $status = $asset->Status();
    }
  }
  else {
    if (defined $status) {
      $self->{STATUS} = $status;
    }
    else {
      $status = $self->{STATUS};
    }
  }
  return $status;
}

# RAS::Asset->add_ip_interface() method
sub add_ip_interface {
# Desc: Adds/updates an ethernet interface to the asset
# Input: 1) $ I  RAS::IP_Interface object
# Returns: undef: on error
  my $self = shift;
  if ($#_ != 0) {
    return undef;
  }
  my ($IF) = @_;

  my $asset = $self->asset();
  if (defined $asset) {
    my $name = $IF->name();
    my $ip = $IF->ipaddr();
    my $mac = $IF->macaddr();

    # Updates interface if it already exists
    my $oldIF;
    if (defined ($oldIF = $self->get_ip_interface($name))) {
      # Update IP and MAC if defined
      my $at_ip = $oldIF->at_ip();
      $ip ne '' && $at_ip->SetIP($ip);
      $mac ne '' && $at_ip->SetMAC($mac);
    }
    else {
      # Load the interface directly into AT
      my ($ret, $msg) = $asset->AddIP(IP => $ip, Interface => $name, MAC => $mac, TCPPorts => [], UDPPorts => [], SilentPorts => 1);
      print "Error: IP $ip not added: $msg\n" unless $ret;

      # Add all aliases
      foreach my $alias (@{$IF->get_aliases()}) {
	my $name = $alias->name();
	my $ip = $alias->ipaddr();
	my ($ret, $msg) = $asset->AddIP(IP => $ip, Interface => $name, TCPPorts => [], UDPPorts => [], SilentPorts => 1);
	print "Error: IP $ip not added: $msg\n" unless $ret;
      }
    }
  }
  else {
    push @{$self->{IP_INTERFACES}}, $IF;
  }
}

# RAS::Asset->get_ip_interface() method
sub get_ip_interface {
# Desc: Gets an ethernet interface associated with the asset
# Input: 1) $ I  IP interface name
# Returns: RAS::IP_Interface object
#          undef: on error
  my $self = shift;
  if ($#_ != 0) {
    return undef;
  }
  my ($name) = @_;
  my $IF;

  my $asset = $self->asset();
  if (defined $asset) {
    my $ips = $asset->IPs();
    while (my $ip = $ips->Next()) {
      if ($ip->Interface() eq $name) {	
	my $IF = RAS::IP_Interface->new($name);
	$IF->at_ip($ip);
	$IF->ipaddr($ip->IP());
	$IF->macaddr($ip->MAC());
	return $IF;
      }
    }
    return undef;
  }
  else {
    foreach my $IF (@{$self->get_all_ip_interfaces()}) {
      if ($IF->name() eq $name) {
	return $IF;
      }
      return undef;
    }
  }
}

# RAS::Asset->get_all_ip_interfaces() method
sub get_all_ip_interfaces {
# Desc: Gets all ethernet interfaces of the asset
# Input: None
# Returns: \@  array of RAS::IP_Interface objects
  my $self = shift;

  my $asset = $self->asset();
  if (defined $asset) {
    my @IFs;
    my $ips = $asset->IPs();
    while (my $ip = $ips->Next()) {
      my $IF = RAS::IP_Interface->new($ip->Interface());
      $IF->at_ip($ip);
      $IF->ipaddr($ip->IP());
      $IF->macaddr($ip->MAC());
      push @IFs, $IF;
    }
    return \@IFs;
  }
  else {
    return \@{$self->{IP_INTERFACES}};
  }
}

# RAS::Asset->custom_field_value() method
sub custom_field_value {
# Desc: Gets or sets a custom field value
# Input: 1) $ I  Custom field name
#        2) $ I? Optional custom field value
# Returns: custom field value
#          undef: on error
  my $self = shift;
  if ($#_ != 0 && $#_ != 1) {
    return undef;
  }
  my ($CFname, $value) = @_;

  my $asset = $self->asset();
  if (defined $asset) {
    if (defined $value) {
      my ($ret, $msg) = $asset->AddCustomFieldValue( Field => $CFname, Value => $value );
      if (!$ret) {
	print STDERR "Error updating custom field for ", $self->name(), ": $msg\n";
	return undef;
      }
      return $value;
    }
    else {
      return $asset->FirstCustomFieldValue($CFname);
    }
  }
  else {
    if (defined $value) {
      $self->{CF_VALS}{$CFname} = $value;
    }
    else {
      $value = $self->{CF_VALS}{$CFname};
    }
  }
  return $value;
}

# RAS::Asset->get_all_custom_fields() method
sub get_all_custom_fields {
# Desc: Gets all custom fields (with data) in the asset
# Input: None
# Returns: \%  hash of custom fields currently set key=CFname value=CFvalue
  my $self = shift;

  my $asset = $self->asset();
  if (defined $asset) {
    my %CFvals;
    my $CFvalues = $asset->CustomFieldValues();
    while (my $CF = $CFvalues->Next()) {
      $CFvals{$CF->CustomFieldObj()->Name()} = $CF->Content();
    }
    return \%CFvals;
  }
  else {
    return \%{$self->{CF_VALS}};
  }
}

# RAS::Asset->create() method
sub create {
# Desc: Creates the asset within Asset Tracker
#       Any asset data currently in the object will be added to the AT asset
# Input: None
# Returns: RTx::AssetTracker::Asset object
#          undef: on error
  my $self = shift;

  # Initialize RT
  RAS->init_RT();

  # Only create if the asset does not already exist
  if (defined $self->load()) {
    return undef;
  }

  # Create the asset in AT
  my $asset = RTx::AssetTracker::Asset->new($RT::SystemUser);
  my $name = $self->name();

  my (%CFMap, @CFargs);
  # Create mapping of CF name to CF id
  my $CFObjs = RT::CustomFields->new($RT::SystemUser);
  $CFObjs->UnLimit();
  $CFObjs->LimitToLookupType(RAS::CustomField::applies_to_lookup('Assets'));
  while (my $CF = $CFObjs->Next()) {
    $CFMap{$CF->Name()} = $CF->id();
  }

  # Prepare custom fields
  my $CFs = $self->get_all_custom_fields();
  foreach my $CFname (keys %$CFs) {
    if (exists $CFMap{$CFname}) {
      push @CFargs, "CustomField-$CFMap{$CFname}", $CFs->{$CFname};
    }
    else {
      print STDERR "Warning!  Custom Field does not exist for asset '$name': $CFname\n";
    }
  }

  # Create the asset
  my ($id, $trans, $err) =
    $asset->Create( Name => $name, Description => $self->description(),
		    Status => $self->status(),
		    Type => $self->type(), _RecordTransaction => 1,
		    @CFargs );

  unless ($id) {
    print STDERR "Error: Asset '$name' not created: $err\n";
    return undef;
  }
  ${RAS::verbose} && print "Created asset; $name\n";

  my $IFs = $self->get_all_ip_interfaces();
  $self->asset($asset);

  # Add all IP interfaces
  foreach my $IF (@$IFs) {
    $self->add_ip_interface($IF);
  }

  return $asset;
}

# RAS::Asset->load() method
sub load {
# Desc: Loads the asset from Asset Tracker
#       NOTE: Any method calls updating data that are called *after*
#             RAS::Asset->load() will modify the actual asset in AT
# Input: 1) $ I?  Optional Asset name
# Returns: AT::Asset object
#          undef: if asset doesn't exist or on error
  my $self = shift;
  my ($name) = @_;

  # Initialize RT
  RAS->init_RT();

  if (!defined $name) {
    $name = $self->name();
  }
  # Get asset info  -- turn off RT logging for a sec
  my $asset = RTx::AssetTracker::Asset->new($RT::SystemUser);
  my $logger = $RT::Logger;
  $RT::Logger = '';
  my $ret = eval { $asset->Load($name); };
  if (defined $ret) {
    $asset = $self->asset($asset);
  }
  else {
    print STDERR "Error: Unable to load asset: ", $name, "\n";
    $asset = undef;
  }
  $RT::Logger = $logger;
  return $asset;
}

# RAS::Asset->load() method
sub unload {
# Desc: Unloads the Asset Tracker asset
# Input: None
# Returns: None
#          undef: on error
  my $self = shift;

  $self->asset(undef);
}



#-------- RAS::AssetType Object --------#

package RAS::AssetType;
use strict;
use warnings;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
             &name
             &description
             &add_component
             &get_components
             &add_custom_field
             &get_custom_fields
             &create
	     );

sub new {
# Desc: RAS::AssetType object constructor
# Input: $ I  Asset Type name
# Returns: $  blessed object, empty
#          undef: on error
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my $self = {};
  bless($self, $class);

  if ($#_ != 0) {
    return undef;
  }
  my ($name) = @_;

  $self->{NAME} = $name;
  $self->{DESCRIPTION} = $name;
  $self->{COMPONENTS} = new RAS::CustomField("Components of $name", 'Assets', 'Select', 1);
  $self->{COMPONENTS}->description("Hardware components related to $name asset type");
  $self->{CUSTOMFIELDS} = [];
  return $self;
}

# RAS::AssetType->name() method
sub name {
# Desc: Gets or sets AssetType name
# Input: 1) $ I?  Optional asset type name
# Returns: $  asset type name
  my $self = shift;
  if (@_) {
    $self->{NAME} = shift;
  }
  return $self->{NAME};
}

# RAS::AssetType->description() method
sub description {
# Desc: Gets or sets AssetType description
# Input: 1) $ I?  Optional asset type description
# Returns: $  asset type description
  my $self = shift;
  if (@_) {
    $self->{DESCRIPTION} = shift;
  }
  return $self->{DESCRIPTION};
}

# RAS::AssetType->add_component() method
sub add_component {
# Desc: Adds a component to the asset type
# Input: 1) $ I  Component name
#        2) $ I? Optional component description
# Returns: $  Component name
#          undef: on error
  my $self = shift;

  if ($#_ != 0 && $#_ != 1) {
    return undef;
  }
  my ($comp_name, $comp_desc) = @_;

  if (defined $comp_desc) {
    $self->{COMPONENTS}->add_value($comp_name, $comp_desc);
  }
  else {
    $self->{COMPONENTS}->add_value($comp_name);
  }
  return $comp_name;
}

# RAS::AssetType->get_components() method
sub get_components {
# Desc: Gets all components of the asset type
# Input: None
# Returns: RAS::CustomField object with components loaded as 'Combobox' values
  my $self = shift;
  return $self->{COMPONENTS};
}

# RAS::AssetType->add_custom_field() method
sub add_custom_field {
# Desc: Adds a custom field to the asset type
# Input: 1) $ I  RAS::CustomField object
# Returns: undef: on error
  my $self = shift;

  if ($#_ != 0) {
    return undef;
  }
  my ($CF) = @_;

  push @{$self->{CUSTOMFIELDS}}, $CF;
  return 0;
}

# RAS::AssetType->get_custom_fields() method
sub get_custom_fields {
# Desc: Gets all custom fields of the asset type
# Input: None
# Returns: \@  array of RAS::CustomField objects
  my $self = shift;
  return \@{$self->{CUSTOMFIELDS}};
}

# RAS::AssetType->create() method
sub create {
# Desc: Creates the asset type within Asset Tracker
# Input: None
# Returns: 0: on success
#          1: on error
  my $self = shift;
  no warnings qw(once);
  my ($ret, $msg);

  my $name = $self->name();
  my $desc = $self->description();

  # Initialize RT
  RAS->init_RT();

  # Run operations as a privileged user
  my $priv = RT::Group->new( $RT::SystemUser );
  $priv->LoadSystemInternalGroup('Privileged'); 

  # Create new AssetTracker Type
  my $type = RTx::AssetTracker::Type->new($RT::SystemUser);
  if ($type->Load($name)) {
    print STDERR "Error: Asset Type '$name' already exists\n";
    return 1;
  }

  ($ret, $msg) = $type->Create(Name => $name, Description => $desc);
  unless ($ret) {
    print STDERR "Error: Couldn't create Asset Type '$name': $msg\n";
    return 1;
  }

  $verbose && print "Asset Type created: $name\n";

  # Grant rights for new asset
  $priv->PrincipalObj->GrantRight(Object => $type, Right => '\SeeType');
  $priv->PrincipalObj->GrantRight(Object => $type, Right => '\ShowAsset');
  $priv->PrincipalObj->GrantRight(Object => $type, Right => '\Own Asset');

  # Create custom fields for new asset type
 CF: foreach my $CFObj (@{$self->get_custom_fields()}, $self->get_components()) {
    my $CFname = $CFObj->name();
    # Load or create the custom field
    my $CF;
    unless (defined ($CF = $CFObj->load())) {
      unless (defined ($CF = $CFObj->create(0))) {
	next CF;
      }
    }

    if ( $CFname !~ /^Components of $name$/ ) {
        # Associate Custom Field with newly created asset type
        ($ret, $msg) = $CF->AddToObject($type);
        if ($ret) {
          $verbose && print "Added Custom Field '$CFname' to asset type '$name'\n";
        }
        else {
          print STDERR "Error: Couldn't add Custom Field '$CFname' to asset type '$name': $msg\n";
        }
    }
  }
}



#-------- RAS::CustomField Object --------#

package RAS::CustomField;
use strict;
use warnings;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
             &name
             &description
             &applies_to
             &applies_to_lookup
             &type
             &add_value
             &get_values
             &get_value_desc
             &multiple
             &create
             &enable
             &load
	     );

sub new {
# Desc: RAS::CustomField object constructor
# Input: 1) $ I Custom field name
#        2) $ I Applies to (Tickets,Groups,Users,Assets,Events,Ticket Transactions)
#        3) $ I CF type (Select,Freeform,Text,Wikitext,Image,Binary,Combobox)
#        4) $ I Multiple Values: 0: custom field can have only one value
#                                1: custom field can have multiple values
# Returns: $ blessed object, empty
#          undef: on error
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my $self = {};
  bless($self, $class);

  if ($#_ != 3) {
    return undef;
  }
  my ($field_name, $applies_to, $field_type, $multiple) = @_;

  $self->{NAME} = $field_name;
  $self->{DESCRIPTION} = undef;
  $self->{APPLIES_TO} = undef;
  if (!defined $self->applies_to($applies_to)) {
    return undef;
  }
  $self->{TYPE} = undef;
  if (!defined $self->type($field_type)) {
    return undef;
  }
  $self->{MULTIPLE} = undef;
  if (!defined $self->multiple($multiple)) {
    return undef;
  }
  $self->{VALUES} = [];
  $self->{VALUE_DESC} = {};
  return $self;
}

# RAS::CustomField->name() method
sub name {
# Desc: Gets or sets custom field name
# Input: 1) $ I?  Optional custom field name
# Returns: $ custom field name
  my $self = shift;
  if (@_) {
    $self->{NAME} = shift;
  }
  return $self->{NAME};
}

# RAS::CustomField->description() method
sub description {
# Desc: Gets or sets custom field description
# Input: 1) $ I?  Optional custom field description
# Returns: $ custom field description
  my $self = shift;
  if (@_) {
    $self->{DESCRIPTION} = shift;
  }
  return $self->{DESCRIPTION};
}

# RAS::CustomField->applies_to() method
sub applies_to {
# Desc: Gets or sets what kind of RT/AT entity the custom field applies to
# Input: 1) $ I?  Optional entity type custom field applies to
#                 can be: (Tickets,Groups,Users,Assets,Events,Ticket Transactions)
# Returns: $ entity type custom field applies to
#          undef: on error
  my $self = shift;
  if (@_) {
    my $applies_to = shift;
    if ($applies_to =~ /^(Tickets|Groups|Users|Assets|Events|Ticket Transactions)$/) {
      $self->{APPLIES_TO} = $applies_to;
    } else {
      return undef;
    }
  }
  return $self->{APPLIES_TO};
}

# RAS::CustomField->applies_to_lookup() method
sub applies_to_lookup {
# Desc: Gets the non-friendly RT lookup name for the applies_to name
# Input: 1) $? I  Optional applies-to name
# Returns: $ lookup name
#          undef: on error
  my $self = shift;

  # Initialize RT
  RAS->init_RT();

  my $applies_to;
  # Allow this method to be called directly
  if (UNIVERSAL::isa($self, "RAS::CustomField")) {
    $applies_to = $self->applies_to();
  }
  else {
    $applies_to = $self;
    unless ($applies_to =~ /^(Tickets|Groups|Users|Assets|Events|Ticket Transactions)$/) {
      return undef;
    }
  }
  my $applies_to_lookup = undef;
  if (defined $applies_to) {
    my $CF = RT::CustomField->new($RT::SystemUser);
    foreach my $lookup ($CF->LookupTypes()) {
      my $type = $CF->FriendlyLookupType($lookup);
      if ($type eq $applies_to) {
	$applies_to_lookup = $lookup;
	last;
      }
    }
  }
  return $applies_to_lookup;
}

# RAS::CustomField->type() method
sub type {
# Desc: Gets or sets custom field type
# Input: 1) $ I?  Optional custom field type
#                 can be: (Select,Freeform,Text,Wikitext,Image,Binary,Combobox)
# Returns: $ custom field type
#          undef: on error
  my $self = shift;
  if (@_) {
    my $type = shift;
    if ($type =~ /^(Select|Freeform|Text|Wikitext|Image|Binary|Combobox)$/) {
      $self->{TYPE} = $type;
    } else {
      return undef;
    }
  }
  return $self->{TYPE};
}

# RAS::CustomField->add_value() method
sub add_value {
# Desc: Adds a potential value for 'Select' or 'Combobox' type custom fields
# Input: 1) $ I  value string
#        2) $ I? Optional value description
# Returns: undef: on error
  my $self = shift;

  if ($#_ != 0 && $#_ != 1) {
    return undef;
  }
  if ($self->type() !~ /^(Select|Combobox)$/) {
    print STDERR "Warning: Can only add values to 'Select' or 'Combobox' type custom fields\n";
    return undef;
  }
  my ($value, $desc) = @_;

  push @{$self->{VALUES}}, $value;
  if (defined $desc) {
    $self->{VALUE_DESC}{$value} = $desc;
  }
  return 0;
}

# RAS::CustomField->get_values() method
sub get_values {
# Desc: Gets all potential custom field values
# Input: None
# Returns: \@  array of potential values
  my $self = shift;
  return \@{$self->{VALUES}};
}

# RAS::CustomField->get_value_desc() method
sub get_value_desc {
# Desc: Gets description for 'Select' or 'Combobox' type custom fields values
# Input: 1) $ I  value name
# Returns: $ description of given value
#          undef: on error
  my $self = shift;
  if ($#_ != 0) {
    return undef;
  }
  my ($value) = @_;
  if (exists $self->{VALUE_DESC}{$value}) {
    return $self->{VALUE_DESC}{$value};
  }
  else {
    return undef;
  }
}

# RAS::CustomField->multiple() method
sub multiple {
# Desc: Gets or sets custom field 'multiple value' flag
# Input: 1) $ I?  Optional 'multiple value' flag:
#                   0: custom field can have only one value
#                   1: custom field can have multiple values
# Returns: $ custom field multiple
#          undef: on error
  my $self = shift;
  if (@_) {
    my $multiple = shift;
    if ($multiple =~ /^(0|1)$/) {
      $self->{MULTIPLE} = $multiple;
    }
    else {
      return undef;
    }
  }
  return $self->{MULTIPLE};
}

# RAS::CustomField->create() method
sub create {
# Desc: Creates the custom field within RT
# Input: 1) $? I  Optional 'enable' flag
#                 1: enable CF upon creation (default except for 'Asset' CFs)
#                 0: do not enable custom field upon creation
# Returns: RT::CustomField object
#          undef: on error
  my $self = shift;

  # Initialize RT
  RAS->init_RT();

  no warnings qw(once);
  my ($ret, $msg);
  my $enable = 1;
  if (@_) {
    $enable = shift;
    if ($enable !~ /^(0|1)$/) {
      return undef;
    }
  }

  # Run operations as a privileged user
  my $priv = RT::Group->new( $RT::SystemUser );
  $priv->LoadSystemInternalGroup('Privileged');

  my $name = $self->name();
  my $desc = $self->description() ? $self->description() : $name;
  my $datatype = $self->type();
  my $applies_to = $self->applies_to();
  my $applies_to_lookup = $self->applies_to_lookup();
  if ($self->multiple()) {
    $datatype .= 'Multiple';
  }
  else {
    $datatype .= 'Single';
  }

  my $CF = RT::CustomField->new($RT::SystemUser);
  ($ret, $msg) = $CF->LoadByName(Name => $name);
  if ($ret) {
    print STDERR "Error: Custom Field '$name' already exists\n";
    return undef;
  }

  my $max = ($datatype =~ /Single/) ? 1 : 0;
  ($ret, $msg) = $CF->Create( Name => $name, Description => $desc,
			      Type => $datatype, MaxValues => $max,
			      LookupType => $applies_to_lookup,
			    );

  unless ($ret) {
    print STDERR "Error: Couldn't create Custom Field '$name': $msg\n";
    return undef;
  }

  $verbose && print "CF created: $name\n";

  # Grant rights for new custom field
  $priv->PrincipalObj->GrantRight(Object => $CF, Right => 'SeeCustomFiel\d');

  # Add all values for 'Select' or 'Combobox' type custom fields
  if ($datatype =~ /^(Select|Combobox)/) {
    foreach my $val (@{$self->get_values()}) {
      my $val_desc = $self->get_value_desc($val) ? $self->get_value_desc($val) : '';
      ($ret, $msg) = $CF->AddValue(Name => $val, Description => $val_desc);
      unless ($ret) {
	print STDERR "Error: Couldn't add value '$val' to Custom Field '$name': $msg\n";
      }
    }
  }

  # Enable the custom field (except for Assets/Events -- enable per Asset Type)
  if ($enable && $applies_to !~ /^(Assets|Events)$/o) {
    my ($object, $type);
    if ($applies_to eq 'Tickets') {
      $object = RT::Queue->new($RT::SystemUser);
      $type = 'Tickets';
    }
    elsif ($applies_to eq 'Groups') {
      $object = RT::Group->new($RT::SystemUser);
      $type = 'Groups';
    }
    elsif ($applies_to eq 'Users') {
      $object = RT::User->new($RT::SystemUser);
      $type = 'Users';
    }
    elsif ($applies_to eq 'Ticket Transactions') {
      $object = RT::Queue->new($RT::SystemUser);
      $type = 'Ticket Transactions';
    }

    ($ret, $msg) = $CF->AddToObject($object);
    if ($ret) {
      $verbose && print "Added Custom Field '$name' for $type\n";
    }
    else {
      print STDERR "Error: Couldn't add Custom Field '$name' for $type: $msg\n";
    }
  }

  return $CF;
}

# RAS::CustomField->load() method
sub load {
# Desc: Returns the corresponding RT::CustomField object
# Input: None
# Returns: $ RT::CustomField objects
#          undef: on error
  my $self = shift;

  # Initialize RT
  RAS->init_RT();

  my $CF = RT::CustomField->new($RT::SystemUser);
  my ($ret, $msg) = $CF->LoadByName(Name => $self->name());
  if ($ret) {
    return $CF;
  }
  return undef;
}



#-------- RAS::IP_Interface Object --------#

package RAS::IP_Interface;
use strict;
use warnings;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
             &name
             &ipaddr
             &macaddr
             &add_alias
             &get_aliases
             &at_ip
            );

sub new {
# Desc: RAS::IP_Interface object constructor
# Input: 1) $ I Interface name
# Returns: $ blessed object, empty
#          undef: on error
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my $self = {};
  bless($self, $class);

  if ($#_ != 0) {
    return undef;
  }
  my ($name) = @_;

  $self->{NAME} = $name;
  $self->{IPADDR} = undef;
  $self->{MAC} = undef;
  $self->{ALIASES} = [];
  $self->{AT_IP} = undef;
  return $self;
}

# RAS::IP_Interface->name() method
sub name {
# Desc: Gets or sets ethernet interface name
# Input: 1) $ I?  Optional ethernet interface name
# Returns: $ ethernet interface name
  my $self = shift;
  if (@_) {
    $self->{NAME} = shift;
  }
  return $self->{NAME};
}

# RAS::IP_Interface->ipaddr() method
sub ipaddr {
# Desc: Gets or sets interface's IP address
# Input: 1) $ I?  Optional IP address
# Returns: $ interface's IP address
  my $self = shift;
  if (@_) {
    $self->{IPADDR} = shift;
  }
  return $self->{IPADDR};
}

# RAS::IP_Interface->macaddr() method
sub macaddr {
# Desc: Gets or sets interface's MAC address
# Input: 1) $ I?  Optional MAC address
# Returns: $ interface's MAC address
  my $self = shift;
  if (@_) {
    $self->{MAC} = shift;
  }
  return $self->{MAC};
}

# RAS::IP_Interface->add_alias() method
sub add_alias {
# Desc: Adds an alias of the interface
# Input: 1) $ I  RAS::IP_Interface object
# Returns: undef: on error
  my $self = shift;

  if ($#_ != 0) {
    return undef;
  }
  my ($alias) = @_;

  push @{$self->{ALIASES}}, $alias;
  return 0;
}

# RAS::IP_Interface->get_aliases() method
sub get_aliases {
# Desc: Gets all aliases of the interface
# Input: None
# Returns: \@  array of RAS::IP_Interface objects
  my $self = shift;
  return \@{$self->{ALIASES}};
}

# RAS::IP_Interface->at_ip() method
sub at_ip {
# Desc: Gets or sets RTx::AssetTracker::IP object
# Input: 1) $ I?  Optional RTx::AssetTracker::IP object
# Returns: $ RTx::AssetTracker::IP object
  my $self = shift;
  if (@_) {
    $self->{AT_IP} = shift;
  }
  return $self->{AT_IP};
}



#-------- RAS::Ticket Object --------#

package RAS::Ticket;
use strict;
use warnings;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
             &requester
             &asset
             &subject
             &body
             &owner
             &queue
             &priority
             &priority_max
             &create
	     );

sub new {
# Desc: RAS::Ticket object constructor
# Input: 1) $ I  Requestor
#        1) $ I  Asset name
# Returns: $  blessed object, empty
#          undef: on error
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my $self = {};
  bless($self, $class);

  if ($#_ != 1) {
    return undef;
  }
  my ($requestor, $asset) = @_;

  $self->{REQUESTOR} = $requestor;
  $self->{ASSET} = $asset;
  $self->{SUBJECT} = undef;
  $self->{BODY} = undef;
  $self->{OWNER} = undef;
  $self->{QUEUE} = undef;
  $self->{PRIORITY} = undef;
  $self->{PRIORITY_MAX} = undef;

  return $self;
}

# RAS::Ticket->requestor() method
sub requestor {
# Desc: Gets or sets Ticket requestor
# Input: 1) $ I?  Optional ticket requestor
# Returns: $  requestor name
  my $self = shift;
  if (@_) {
    $self->{REQUESTOR} = shift;
  }
  return $self->{REQUESTOR};
}

# RAS::Ticket->asset() method
sub asset {
# Desc: Gets or sets Ticket asset name
# Input: 1) $ I?  Optional ticket asset name
# Returns: $  asset name
  my $self = shift;
  if (@_) {
    $self->{ASSET} = shift;
  }
  return $self->{ASSET};
}

# RAS::Ticket->subject() method
sub subject {
# Desc: Gets or sets Ticket subject
# Input: 1) $ I?  Optional ticket subject
# Returns: $  Ticket subject
  my $self = shift;
  if (@_) {
    $self->{SUBJECT} = shift;
  }
  return $self->{SUBJECT};
}

# RAS::Ticket->body() method
sub body {
# Desc: Gets or sets Ticket body
# Input: 1) $ I?  Optional ticket body
# Returns: $  Ticket body
  my $self = shift;
  if (@_) {
    $self->{BODY} = shift;
  }
  return $self->{BODY};
}

# RAS::Ticket->owner() method
sub owner {
# Desc: Gets or sets Ticket's initial owner
# Input: 1) $ I?  Optional ticket owner
# Returns: $  Ticket owner
  my $self = shift;
  if (@_) {
    $self->{OWNER} = shift;
  }
  return $self->{OWNER};
}

# RAS::Ticket->queue() method
sub queue {
# Desc: Gets or sets Ticket queue
# Input: 1) $ I?  Optional ticket queue
# Returns: $  Ticket queue
  my $self = shift;
  if (@_) {
    $self->{QUEUE} = shift;
  }
  return $self->{QUEUE};
}

# RAS::Ticket->priority() method
sub priority {
# Desc: Gets or sets Ticket priority
# Input: 1) $ I?  Optional ticket priority
# Returns: $  Ticket priority
  my $self = shift;
  if (@_) {
    $self->{PRIORITY} = shift;
  }
  return $self->{PRIORITY};
}

# RAS::Ticket->priority_max() method
sub priority_max {
# Desc: Gets or sets Ticket's maximum possible priority
# Input: 1) $ I?  Optional ticket priority_max
# Returns: $  Ticket priority_max
  my $self = shift;
  if (@_) {
    $self->{PRIORITY_MAX} = shift;
  }
  return $self->{PRIORITY_MAX};
}

# RAS::Ticket->history() method
sub history {
# Desc: Gets Ticket's history
# Input: 1) None
# Returns: $  Ticket history
  my $self = shift;

  return;
}


# RAS::Ticket->create() method
sub create {
# Desc: Creates the asset within Asset Tracker
# Input: None
# Returns: 0: on success
#          1: on error
  my $self = shift;
  no warnings qw(once);
  my (%CFMap, @CFargs);

  # Initialize RT
  RAS->init_RT();

  # Load the requested asset
  my $org = $RT::Organization;
  my $assetObj = RTx::AssetTracker::Asset->new($RT::SystemUser);
  $assetObj->Load($self->asset());
  my $assetID = $assetObj->id();

  # Create new ticket associated with the asset
  my $requestor = $self->requestor();
  my $subject = $self->subject();
  my $body = $self->body();
  my $owner = $self->owner();
  my $queue = $self->queue();
  my $priority = $self->priority();
  my $priority_max = $self->priority_max();

  my $ticket = new RT::Ticket($RT::SystemUser);
  my $ticket_body = MIME::Entity->build(Data => $body,
					Type => 'text/plain');
  my %ticket_vals = ( Queue => $queue,
		      Subject => $subject,
		      Requestor => $requestor,
		      Owner => $owner,
		      InitialPriority => $priority,
		      FinalPriority => $priority_max,
		      MIMEObj => $ticket_body,
		      RefersTo => "at://$org/asset/$assetID",
		    );
   my ($id, $transaction_object, $err) = $ticket->Create(%ticket_vals);
   if ($err) {
     print STDERR "$err\n";
     return 1;
   }
  return 0;
}



#-------- RAS::EventType Object --------#

package RAS::EventType;
use strict;
use warnings;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
             &name
             &description
             &add_custom_field
             &get_custom_fields
             &create
	     );

sub new {
# Desc: RAS::EventType object constructor
# Input: $ I  Event Type name
# Returns: $  blessed object, empty
#          undef: on error
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my $self = {};
  bless($self, $class);

  if ($#_ != 0) {
    return undef;
  }
  my ($name) = @_;

  $self->{NAME} = $name;
  $self->{DESCRIPTION} = $name;
  $self->{CUSTOMFIELDS} = [];
  return $self;
}

# RAS::EventType->name() method
sub name {
# Desc: Gets or sets EventType name
# Input: 1) $ I?  Optional event type name
# Returns: $  event type name
  my $self = shift;
  if (@_) {
    $self->{NAME} = shift;
  }
  return $self->{NAME};
}

# RAS::EventType->description() method
sub description {
# Desc: Gets or sets EventType description
# Input: 1) $ I?  Optional event type description
# Returns: $  event type description
  my $self = shift;
  if (@_) {
    $self->{DESCRIPTION} = shift;
  }
  return $self->{DESCRIPTION};
}

# RAS::EventType->add_custom_field() method
sub add_custom_field {
# Desc: Adds a custom field to the event type
# Input: 1) $ I  RAS::CustomField object
# Returns: undef: on error
  my $self = shift;

  if ($#_ != 0) {
    return undef;
  }
  my ($CF) = @_;

  push @{$self->{CUSTOMFIELDS}}, $CF;
  return 0;
}

# RAS::EventType->get_custom_fields() method
sub get_custom_fields {
# Desc: Gets all custom fields of the event type
# Input: None
# Returns: \@  array of RAS::CustomField objects
  my $self = shift;
  return \@{$self->{CUSTOMFIELDS}};
}

# RAS::EventType->create() method
sub create {
# Desc: Creates the event type within Event Tracker
# Input: None
# Returns: 0: on success
#          1: on error
  my $self = shift;
  no warnings qw(once);
  my ($ret, $msg);

  my $name = $self->name();
  my $desc = $self->description();

  # Initialize RT
  RAS->init_RT();

  # Run operations as a privileged user
  my $priv = RT::Group->new( $RT::SystemUser );
  $priv->LoadSystemInternalGroup('Privileged');

  # Create new EventTracker Type
  my $type = RTx::EventTracker::Type->new($RT::SystemUser);
  if ($type->Load($name)) {
    print STDERR "Error: Event Type '$name' already exists\n";
    return 1;
  }

  ($ret, $msg) = $type->Create(Name => $name, Description => $desc);
  unless ($ret) {
    print STDERR "Error: Couldn't create Event Type '$name': $msg\n";
    return 1;
  }

  $verbose && print "Event Type created: $name\n";

  # Grant rights for new event
  $priv->PrincipalObj->GrantRight(Object => $type, Right => '\SeeType');
  $priv->PrincipalObj->GrantRight(Object => $type, Right => '\ShowEvent');
  $priv->PrincipalObj->GrantRight(Object => $type, Right => '\Own Event');

  # Create custom fields for new event type
 CF: foreach my $CFObj (@{$self->get_custom_fields()}) {
    my $CFname = $CFObj->name();
    # Load or create the custom field
    my $CF;
    unless (defined ($CF = $CFObj->load())) {
      unless (defined ($CF = $CFObj->create(0))) {
	next CF;
      }
    }

    # Associate Custom Field with newly created event type
    ($ret, $msg) = $CF->AddToObject($type);
    if ($ret) {
      $verbose && print "Added Custom Field '$CFname' to event type '$name'\n";
    }
    else {
      print STDERR "Error: Couldn't add Custom Field '$CFname' to event type '$name': $msg\n";
    }
  }
  return 0;
}


#-------- RAS::Filter Object --------##
package RAS::Filter;
use strict;
use warnings;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
             &type
             &add_data
             &get_data
             &blacklist
             &whitelist
             &pipe_cmd
             &create_pipe
             &write_to_pipe
             &read_from_pipe
             &passthrough
             &prefilter
             &postfilter
             &add_context_def
             &get_context_defs
             &add_open_context
             &get_open_contexts
             &destroy_context
             &skip_prefilter
             &skip_mainfilter
             &skip_postfilter
             &filter
             &flush
	    );

sub new {
# Desc: RAS::Filter object constructor
# Input: 1) $ I  Filter type (one of 'line, pipe, context')
# Returns: $  blessed object, empty
#          undef: on error
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my $self = {};
  bless($self, $class);

  if ($#_ != 0) {
    return undef;
  }
  my ($type) = @_;

  if (!defined ($self->type($type))) {
    return undef;
  }
  $self->{DATA} = [];
  $self->{PREFILTERS} = [];
  $self->{POSTFILTERS} = [];
  $self->{SKIP_PRE} = 0;
  $self->{SKIP_MAIN} = 0;
  $self->{SKIP_POST} = 0;

  if ($type eq 'line') {
    $self->{BLACKLIST} = [];
    $self->{WHITELIST} = [];
    $self->{PASSTHROUGH} = {};
  }
  elsif ($type eq 'pipe') {
    $self->{CMD} = undef;
    $self->{PIPE_IN} = undef;
    $self->{PIPE_OUT} = undef;
    $self->{CMD_IN} = undef;
    $self->{CMD_OUT} = undef;
  }
  elsif ($type eq 'context') {
    $self->{CONTEXT_DEFS} = {};
    $self->{OPEN_CONTEXTS} = {};
  }

  return $self;
}

# RAS::Filter->type() method
sub type {
# Desc: Gets or sets Filter type (one of 'line, pipe, context')
# Input: 1) $ I?  Optional filter type
# Returns: $  filter type
#          undef: on error
  my $self = shift;
  my ($type) = @_;

  if (defined $type) {
    if ($type =~ /^(line|pipe|context)$/) {
      $self->{TYPE} = $type;
    }
    else {
      return undef;
    }
  }
  return $self->{TYPE};
}

# RAS::Filter->add_data() method
sub add_data {
# Desc: Add data and associated metadata to the filter
# Input: 1) \@($,%) Array of data/metadata pairs ($data, %metadata_hash)
# Returns: undef: on error
  my $self = shift;
  if ($#_ < 0) {
    return undef;
  }
  my ($data) = @_;
  foreach my $entry (@$data) {
    push @{$self->{DATA}}, $entry;
  }
}

# RAS::Filter->get_data() method
sub get_data {
# Desc: Gets data and associated metadata of the filter
# Input: None
# Returns: \@($,%) Array of data/metadata pairs ($data, %metadata_hash)
  my $self = shift;
  return \@{$self->{DATA}};
}

# RAS::Filter->blacklist() method
sub blacklist {
# Desc: Add a regular expression to the set of lines to blacklist
#       or retreive a regular expression of all blacklisted lines
# Input: 1) $ I  Regular expression
# Returns: $ regular expression of blacklisted items
  my $self = shift;
  my ($bl_RE) = @_;

  return undef unless $self->type() eq 'line';

  if (defined $bl_RE) {
    # Remove leading and trailing '/' marks (if included)
    $bl_RE =~ s|^/||; $bl_RE =~ s|/$||;
    # Replace spaces with \s characters
    $bl_RE =~ s/ /\\s/g;
    push @{$self->{BLACKLIST}}, $bl_RE;
  }
  else {
    return join('|', @{$self->{BLACKLIST}});
  }
}

# RAS::Filter->whitelist() method
sub whitelist {
# Desc: Add a regular expression to the set of lines to whitelist
#       or retreive a regular expression of all whitelisted lines
# Input: 1) $ I  Regular expression
# Returns: $ regular expression of whitelisted items
  my $self = shift;
  my ($bl_RE) = @_;

  return undef unless $self->type() eq 'line';

  if (defined $bl_RE) {
    # Remove leading and trailing '/' marks (if included)
    $bl_RE =~ s|^/||; $bl_RE =~ s|/$||;
    # Replace spaces with \s characters
    $bl_RE =~ s/ /\\s/g;
    push @{$self->{WHITELIST}}, $bl_RE;
  }
  else {
    return join('|', @{$self->{WHITELIST}});
  }
}

# RAS::Filter->pipe_cmd() method
sub pipe_cmd {
# Desc: Set a command to pipe input through for 'pipe' type filters
# Input: 1) $ I  Command (takes input on STDIN, write output to STDOUT)
# Returns: $ command
  my $self = shift;
  my ($command) = @_;

  return undef unless $self->type() eq 'pipe';

  if (defined $command) {
    $self->{CMD} = $command;
  }
  else {
    return $self->{CMD};
  }
}

# RAS::Filter->create_pipe() method
sub create_pipe {
# Desc: Fork/exec the pipe_cmd with pipes connected to its STDIN and STDOUT
# Input: None
# Returns: undef: on error
  my $self = shift;

  return undef unless $self->type() eq 'pipe';

  my $cmd = $self->pipe_cmd();
  my ($cmd_in, $cmd_out, $pipe_in, $pipe_out);

  # Open a couple pipes for STDIN and STDOUT of command
  if (! pipe($cmd_in, $pipe_out)) {
    print STDERR "Error: Failed to create STDIN pipe for '$cmd': $!";
    return undef;
  }
  if (! pipe($pipe_in, $cmd_out)) {
    print STDERR "Error: Failed to create STDOUT pipe for '$cmd': $!";
    return undef;
  };

  # Autoflush output pipes
  select((select($$pipe_out), $| = 1)[0]);
  select((select($$cmd_out), $| = 1)[0]);

  # Keep all open pipes in the object
  ($self->{CMD_IN}, $self->{CMD_OUT}, $self->{PIPE_IN}, $self->{PIPE_OUT}) =
    ($cmd_in, $cmd_out, $pipe_in, $pipe_out);


  # Fork/exec the command
  my $pid = fork;
  if ($pid) { # Parent process
    # Close the child pipe (don't need it)
    close $cmd_out;
    close $cmd_in;
  }
  else  { # Child process
    # Close the parent pipe (don't need it)
    close $pipe_out;
    close $pipe_in;

    # Connect STDIN and STDOUT to the pipes
    open(STDIN, "<&" . fileno($cmd_in) )
      or die "Error: Can't redirect STDIN to pipe for '$cmd': $!\n";
    open( STDOUT, ">&" . fileno($cmd_out) )
      or die "Error: Can't redirect STDOUT to pipe for '$cmd': $!\n";

    # autoflush STDOUT
    select STDOUT;  $| = 1;

    exec $cmd or print STDERR "Error: Exec of pipe command failed: $cmd: $!\n";
    exit;
  }
}

# RAS::Filter->write_to_pipe() method
sub write_to_pipe {
# Desc: Write to the piped command
# Input: $ I  Data to write to the piped command
#             Note: Input is assumed to be line buffered.
#                   If there is no newline character, we add one here.
# Returns: undef: on error
  my $self = shift;
  my ($input) = (@_);

  return undef unless $self->type() eq 'pipe';

  # Add a newline if there isn't one already
  if ($input !~ /\n$/) {
    $input =~ s/$/\n/;
  }

  # Write data to pipe.  Finish with an end-of-input marker
  my $pipe_out = $self->{PIPE_OUT};
  print $pipe_out $input;
  print $pipe_out "RAS::END\n";
}

# RAS::Filter->read_from_pipe() method
sub read_from_pipe {
# Desc: Read from the piped command
# Input: None
# Returns: $ output from pipe
  my $self = shift;

  return undef unless $self->type() eq 'pipe';

  # Read data from pipe until end-of-input marker is reached
  my $pipe_in = $self->{PIPE_IN};
  my $data = '';
  $debug && print STDERR "Reading from pipe:\n";   #################3
  while (<$pipe_in>) {
    $debug && print STDERR "pipe_out: *** $_ ***\n";   #################
    last if /^RAS::END$/;
    $data .= $_;
  }
  $debug && print STDERR "Done reading from pipe:\n";   #################3
  return $data;
}

# RAS::Filter->passthrough() method
sub passthrough {
# Desc: Add a regular expression to pass through to a different filter
#       Note: prefilters and postfilters are still applied
# Input: 1) $ I  Regular expression
#        2) $ I  RAS::Filter object
# Returns: undef: on error
  my $self = shift;
  if ($#_ != 1) {
    return undef;
  }
  my ($pt_RE, $filter) = @_;

  return undef unless $self->type() eq 'line';

  # Remove leading and trailing '/' marks (if included)
  $pt_RE =~ s|^/||; $pt_RE =~ s|/$||;
  $self->{PASSTHROUGH}{$pt_RE} = $filter;
}

# RAS::Filter->add_context_def() method
sub add_context_def {
# Desc: Add a new context definition to the filter
# Input: 1) $ I  RAS::Context object
# Returns: undef: on error
  my $self = shift;
  if ($#_ != 0) {
    return undef;
  }
  my ($context) = @_;

  my $ctx_id = scalar(keys %{$self->{CONTEXT_DEFS}});
  $self->{CONTEXT_DEFS}{$ctx_id} = $context;
}

# RAS::Filter->get_context_defs() method
sub get_context_defs {
# Desc: Get all contexts definitions
# Input: None
# Returns: \%  Hash:   key=context ID   value=RAS::Context object
  my $self = shift;
  return \%{$self->{CONTEXT_DEFS}};
}

# RAS::Filter->add_open_context() method
sub add_open_context {
# Desc: Add a new open context to the filter
# Input: 1) $ I  RAS::Context object
#        2) $ I  context ID
# Returns: undef: on error
  my $self = shift;
  if ($#_ != 1) {
    return undef;
  }
  my ($context, $ctx_id) = @_;

  push @{$self->{OPEN_CONTEXTS}{$ctx_id}}, $context;
}

# RAS::Filter->get_open_contexts() method
sub get_open_contexts {
# Desc: Get all open contexts
# Input: None
# Returns: \%  Hash:   key=context ID   value=Array of RAS::Context objects
  my $self = shift;
  return \%{$self->{OPEN_CONTEXTS}};
}

# RAS::Filter->destroy_context() method
sub destroy_context {
# Desc: Destroy a currently open context
# Input: 1) $ I  RAS::Context object
#        2) $ I  context ID
# Returns: undef: on error
  my $self = shift;
  if ($#_ != 1) {
    return undef;
  }
  my ($ctx_id, $context) = @_;

  for (my $idx=0; $idx <= $#{$self->{OPEN_CONTEXTS}{$ctx_id}}; $idx++) {
    my $ctx = $self->{OPEN_CONTEXTS}{$ctx_id}[$idx];
    if ($ctx == $context) {
      splice(@{$self->{OPEN_CONTEXTS}{$ctx_id}}, $idx, 1);
    }
  }
}

# RAS::Filter->prefilter() method
sub prefilter {
# Desc: Add a regular expression to prefilter with a different filter
# Input: 1) $ I  Regular expression
#        2) $ I  RAS::Filter object
# Returns: undef: on error
  my $self = shift;
  if ($#_ != 1) {
    return undef;
  }
  my ($pf_RE, $filter) = @_;
  unless (UNIVERSAL::isa($filter, "RAS::Filter")) {
    warn "RASilience: Error! Wrong type of object passed to RAS::Filter->prefilter()\n";
    return undef;
  }

  # Remove leading and trailing '/' marks (if included)
  $pf_RE =~ s|^/||; $pf_RE =~ s|/$||;
  push @{$self->{PREFILTERS}}, [$pf_RE, $filter];
}

# RAS::Filter->postfilter() method
sub postfilter {
# Desc: Add a regular expression to postfilter with a different filter
# Input: 1) $ I  Regular expression
#        2) $ I  RAS::Filter object
# Returns: undef: on error
  my $self = shift;
  if ($#_ != 1) {
    return undef;
  }
  my ($pf_RE, $filter) = @_;
  unless (UNIVERSAL::isa($filter, "RAS::Filter")) {
    warn "RASilience: Error! Wrong type of object passed to RAS::Filter->postfilter()\n";
    return undef;
  }

  # Remove leading and trailing '/' marks (if included)
  $pf_RE =~ s|^/||; $pf_RE =~ s|/$||;
  push @{$self->{POSTFILTERS}}, [$pf_RE, $filter];
}

# RAS::Filter->skip_prefilter() method
sub skip_prefilter {
# Desc: Gets or sets flag used to skip the prefilter
# Input: 1) $ I?  Optional flag (0 or 1)
# Returns: 0: Do not skip the prefilter stage
#          1: Skip the prefilter stage
  my $self = shift;
  if (@_) {
    $self->{SKIP_PRE} = shift;
  }
  return $self->{SKIP_PRE};
}

# RAS::Filter->skip_mainfilter() method
sub skip_mainfilter {
# Desc: Gets or sets flag used to skip the main filter
# Input: 1) $ I?  Optional flag (0 or 1)
# Returns: 0: Do not skip the main filter stage
#          1: Skip the main filter stage
  my $self = shift;
  if (@_) {
    $self->{SKIP_MAIN} = shift;
  }
  return $self->{SKIP_MAIN};
}

# RAS::Filter->skip_postfilter() method
sub skip_postfilter {
# Desc: Gets or sets flag used to skip the postfilter
# Input: 1) $ I?  Optional flag (0 or 1)
# Returns: 0: Do not skip the postfilter stage
#          1: Skip the postfilter stage
  my $self = shift;
  if (@_) {
    $self->{SKIP_POST} = shift;
  }
  return $self->{SKIP_POST};
}

# RAS::Filter->filter() method
sub filter {
# Desc: Does the actual filtering
# Input: 1) $ I  Data to filter
#        or \@ Array of ($data, %metadata) tuples
# Returns: \@ Array of ($data, %metadata) tuples
  my $self = shift;
  my ($data) = @_;

  if (defined $data) {
    if (ref($data) ne 'ARRAY') {
      $data = [ [ $data, {} ] ];
    }
  }
  else {
    $data = [ ];
  }

  # Apply any pre-filters
  unless ($self->skip_prefilter()) {
    foreach my $tuple (@{$self->{PREFILTERS}}) {
      my ($pre_RE, $prefilter) = @$tuple;
      for (my $idx=0; $idx <= $#$data; $idx++) {
	my ($entry, $metadata) = @{$$data[$idx]};
	if ($entry =~ /$pre_RE/o) {
	  my $filtered = $prefilter->filter($entry);
	  if ($#$filtered < 0) {
	    # Splice out the data if filter is empty	  
	    splice(@$data, $idx, 1);
	  }
	  else {
	    # Splice filtered data (may be multi-entry) into array
	    splice(@$data, $idx, 1, @$filtered);
	  }
	}
      }
    }
  }

  unless ($self->skip_mainfilter()) {
    if ($self->type() eq 'line') {
      for (my $idx=0; $idx <= $#$data; $idx++) {
	my ($entry, $metadata) = @{$$data[$idx]};
	my $passthrough = 0;
	foreach my $pt_RE (keys %{$self->{PASSTHROUGH}}) {
	  # Pass any passthrough matches onto their appropriate filter
	  if ($entry =~ /$pt_RE/) {
	    my $filtered = $self->{PASSTHROUGH}{$pt_RE}->filter($entry);
	    splice(@$data, $idx, 1, @$filtered);
	    $passthrough = 1;
	    last;
	  }
	}
	unless ($passthrough) {
	  # Filter data through whitelist and blacklist regular expressions
	  my $wl_RE = $self->whitelist();
	  my $bl_RE = $self->blacklist();
	  unless ($wl_RE && $entry =~ /$wl_RE/) {
	    if ($bl_RE && $entry =~ /$bl_RE/) {
	      # Splice out the data if blacklist matches
	      splice(@$data, $idx, 1);
	    }
	  }
	}
      }
    } 
    elsif ($self->type() eq 'pipe') {
      # Create command pipe if needed
      if (!defined $self->{PIPE_OUT}) {
	$self->create_pipe();
      }

      # Filter data through the pipe -- retain any previously set metadata
      for (my $idx=0; $idx <= $#$data; $idx++) {
	my ($entry, $metadata) = @{$$data[$idx]};
	$self->write_to_pipe($entry);
	my $filtered = $self->read_from_pipe();
	splice(@$data, $idx, 1, [ [ $entry, $metadata ] ]);
      }
    } 
    elsif ($self->type() eq 'context') {
      my $open_contexts = $self->get_open_contexts();
      for (my $idx=0; $idx <= $#$data; $idx++) {
	my ($entry, $metadata) = @{$$data[$idx]};
	my $context_match = 0;
	# Check if input should be appended to an already open context
	my %ctx_used;
	foreach my $ctx_id (sort {$a <=> $b} keys %$open_contexts) {
	  foreach my $context (@{$$open_contexts{$ctx_id}}) {
	    # Check for matches of any open contexts. If so, add it to context.
	    if ($context->match_main($entry)) {
	      $debug && print "\t *** Adding to Context: $context\n";
	      $debug && print "\t *** data: $entry\n";
	      $ctx_used{$ctx_id} = 1;
	      $context_match = 1;	      
	    }
	    # Check if input ends an open context.
	    if ($context->match_end($entry)) {
	      $debug && print "\t *** Ending context: $context\n";
	      $debug && print "\t *** data: $entry\n";
	      $ctx_used{$ctx_id} = 1;
	      $context_match = 1;
	    }
	  }
	}

	# Check if new context should be opened from input
	my $ctx_defs = $self->get_context_defs();
	foreach my $ctx_id (sort {$a <=> $b} keys %$ctx_defs) {
	  next if $ctx_used{$ctx_id};
	  my $context = $$ctx_defs{$ctx_id};
	  my $clone = undef;
	  # Check if input starts a new context.  If so, create one.
	  if ($context->match_start($entry)) {
	    $debug && print "\t *** New Context from def: $context\n";
	    $debug && print "\t *** data: $entry\n";
	    # Clone the context into a new instance, and reset the original
	    $clone = $context->clone();
	    $debug && print "\t *** Created clone: $clone\n";
	    $self->add_open_context($clone, $ctx_id);
	    $context->reset();
	    $context_match = 1;
	  }
	  # Check if input ends the newly opened context.
	  if (defined $clone && $clone->match_end($entry)) {
	    $debug && print "\t *** Ending context: $context\n";
	    $debug && print "\t *** data: $entry\n";
	    $ctx_used{$ctx_id} = 1;
	    $context_match = 1;
	  }
	}

	if ($context_match) {
	  # The data has been added to a context -- remove it from data array
	  splice(@$data, $idx, 1);
	}
      }

      # Process any completed contexts
      $open_contexts = $self->get_open_contexts();
      foreach my $ctx_id (sort {$a <=> $b} keys %$open_contexts) {
	my @to_destroy;
	foreach my $context (@{$$open_contexts{$ctx_id}}) {
	  if ($context->completed()) {
	    push @to_destroy, $context;
	    my $ctx_data = $context->get_data();
	    my $ctx_meta = $context->get_metadata();
	    $debug && print "\t *** Completed Context $context data:\n";
	    foreach my $entry (@$ctx_data) {
	      if ($entry =~ /RAS::undef/) {
		print STDERR "Warning! Uninterpolated metdata (RAS::undef) passed from context filter!\n";
	      }
	      $debug && print "\t *** $entry\n";
	      if ($context->pass_metadata()) {
		push @$data, [ $entry, $ctx_meta ];
		if ($debug) {
		  foreach my $key (keys %$ctx_meta) {
		    print "\t *** metadata: $key=$$ctx_meta{$key}\n";
		  }
		}	      
	      }
	      else {
		$debug && print "\t *** Not passing along metadata.\n";
		push @$data, [ $entry, {} ];
	      }
	    }
	  }
	}
	foreach my $context (@to_destroy) {
	  $self->destroy_context($ctx_id, $context);
	}
      }
    }
  }

  # Apply any post-filters
  unless ($self->skip_postfilter()) {
    foreach my $tuple (@{$self->{POSTFILTERS}}) {
      my ($post_RE, $postfilter) = @$tuple;
      for (my $idx=0; $idx <= $#$data; $idx++) {
	my ($entry, $metadata) = @{$$data[$idx]};
	if ($entry =~ /$post_RE/) {
	  my $filtered = $postfilter->filter($entry);
	  if ($#$filtered < 0) {
	    # Splice out the data if filter is empty	  
	    splice(@$data, $idx, 1);
	  } else {
	    # Splice filtered data (may be multi-entry) into array
	    splice(@$data, $idx, 1, @$filtered);
	  }
	}
      }
    }
  }
  return $data;
}

# RAS::Filter->flush() method
sub flush {
# Desc: End all open contexts and flush their output;
# Input: None
# Returns: $ flushed filter output
  my $self = shift;
  my $data = [ ];

  # Flush pre-filters, and pass their data through the rest of the filter,
  # skipping the prefilter stage
  $self->skip_prefilter(1);
  foreach my $tuple (@{$self->{PREFILTERS}}) {
    my ($pre_RE, $prefilter) = @$tuple;
    my $filtered = $prefilter->flush();
    push @$data, @$filtered;
  }

  # End any open contexts and call filter() again, forcing context dumps
  my $open_contexts = $self->get_open_contexts();
  foreach my $ctx_id (sort {$a <=> $b} keys %$open_contexts) {
    foreach my $context (@{$$open_contexts{$ctx_id}}) {
      $context->completed(1);
    }
  }
  my $filtered = $self->filter();
  push @$data, @$filtered;

  # Finally, flush post-filters and grab the output
  foreach my $tuple (@{$self->{POSTFILTERS}}) {
    my ($post_RE, $postfilter) = @$tuple;
    my $filtered = $postfilter->flush();
    push @$data, @$filtered;
  }
  return $data;
}


#-------- RAS::Context Object --------##

package RAS::Context;
use strict;
no strict 'refs';
use warnings;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
             &add_start_regexp
             &add_main_regexp
             &add_end_regexp
             &match_regexp
             &match_start
             &match_main
             &match_end
             &quickmatch
             &summarize
             &interval_ttl
             &total_ttl
             &passed_ttl
             &maxlength
             &add_data
             &get_data
             &retain_data
             &set_metadata
             &get_metadata
             &pass_metadata
             &completed
             &clone
             &reset
	    );

sub new {
# Desc: RAS::Context object constructor
# Input: None
# Returns: $  blessed object, empty
#          undef: on error
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my $self = {};
  bless($self, $class);

  if ($#_ != -1) {
    return undef;
  }

  $self->{START} = {};
  $self->{START_ORDER} = [];
  $self->{END} = {};
  $self->{END_ORDER} = [];
  $self->{MAIN} = {};
  $self->{MAIN_ORDER} = [];
  $self->{START_TIME} = undef;
  $self->{LAST_TIME} = undef;
  $self->{INTERVAL_TTL} = undef;
  $self->{TOTAL_TTL} = undef;
  $self->{LENGTH} = 0;
  $self->{MAXLENGTH} = undef;
  $self->{SUMMARY} = undef;
  $self->{QUICKMATCH} = 0;   # Do not quickmatch by default
  $self->{RETAIN_DATA} = 0;  # Do not retain context data by default
  $self->{PASSMETA} = 0;     # Do not pass metadata on by default
  $self->{COMPLETED} = 0;
  $self->{CONTEXT} = [];
  $self->{METADATA} = {};

  return $self;
}

# RAS::Context->add_start_regexp() method
sub add_start_regexp {
# Desc: Set regexp that, if matched, defines the start of a context
# Input: 1) $ I  regexp matching start of context
#        2-9) $ I?  metadata keys for 1st-9th backreferences
#        ** or (instead of Input(2-9) **
#        {} I? Optional subroutine (useful for setting custom metadata)
#              Note: The subroutine is given the RAS::Context object
#                    as its first argument, followed by any $1-$9 backrefs
#                    from the regexp match.
#        Note: Metadata gathered through backreferences can be retreived via
#              the get_metadata() function after any call to match_*(),
#              and can be referenced using the uninterpolated string
#              '$meta{metakey}' in the regexp of any add_*_regexp function.
# Returns: \%  Hash: key=regexp  value=[metakey1, metakey2, ... , metakey9]
#          ** or **
#          \%  Hash: key=regexp  value={} code ref
#          undef: on error
  my $self = shift;
  if (@_) {
    my $regexp = shift;
    if (ref $_[0] eq 'CODE') {
      # Set the code ref to be evaluated when the regexp matches
      $self->{START}{$regexp} = $_[0];
    }
    else {
      # Set the metadata key names corresponding to backrefs in the regexp
      my @meta_keys = @_;
      $self->{START}{$regexp} = [@meta_keys];
    }

    eval { $regexp =~ /$regexp/ };
    if ($@) {
      print STDERR "ERROR: Invalid regexp: $regexp\n";
      return undef;
    }
    push @{$self->{START_ORDER}}, $regexp;
  }
  return \%{$self->{START}};
}

# RAS::Context->add_main_regexp() method
sub add_main_regexp {
# Desc: Add a regexp that, if matched, will add a line to the context
# Input: 1) $ I  regexp to add any line to the context
#        2-9) $ I?  metadata keys for 1st-9th backreferences
#        ** or (instead of Input(2-9) **
#        {} I? Optional subroutine (useful for setting custom metadata)
#              Note: The subroutine is given the RAS::Context object
#                    as its first argument, followed by any $1-$9 backrefs
#                    from the regexp match.
#        Note: Metadata gathered through backreferences can be retreived via
#              the get_metadata() function after any call to match_*(),
#              and can be referenced using the uninterpolated string
#              '$meta{metakey}' in the regexp of any add_*_regexp function.
# Returns: \%  Hash: key=regexp  value=@[metakey1, metakey2, ... , metakey9]
#          ** or **
#          \%  Hash: key=regexp  value={} code ref
#          undef: on error
  my $self = shift;
  if (@_) {
    my $regexp = shift;
    if (ref $_[0] eq 'CODE') {
      # Set the code ref to be evaluated when the regexp matches
      $self->{MAIN}{$regexp} = $_[0];
    }
    else {
      # Set the metadata key names corresponding to backrefs in the regexp
      my @meta_keys = @_;
      $self->{MAIN}{$regexp} = [@meta_keys];
    }

    eval { $regexp =~ /$regexp/ };
    if ($@) {
      print STDERR "ERROR: Invalid regexp: $regexp\n";
      return undef;
    }
    push @{$self->{MAIN_ORDER}}, $regexp;
  }
  return \%{$self->{MAIN}};
}

# RAS::Context->add_end_regexp() method
sub add_end_regexp {
# Desc: Set regexp that, if matched, will end the context
# Input: 1) $ I  regexp to end the context
#        2-9) $ I?  metadata keys for 1st-9th backreferences
#        ** or (instead of Input(2-9) **
#        {} I? Optional subroutine (useful for setting custom metadata)
#              Note: The subroutine is given the RAS::Context object
#                    as its first argument, followed by any $1-$9 backrefs
#                    from the regexp match.
#        Note: Metadata gathered through backreferences can be retreived via
#              the get_metadata() function after any call to match_*(),
#              and can be referenced using the uninterpolated string
#              '$meta{metakey}' in the regexp of any add_*_regexp function.
# Returns: \%  Hash: key=regexp  value=[metakey1, metakey2, ... , metakey9]
#          ** or **
#          \%  Hash: key=regexp  value={} code ref
#          undef: on error
  my $self = shift;
  if (@_) {
    my $regexp = shift;
    my @meta_keys = @_;
    eval { $regexp =~ /$regexp/ };
    if ($@) {
      print STDERR "ERROR: Invalid regexp: $regexp\n";
      return undef;
    }
    push @{$self->{END_ORDER}}, $regexp;
    $self->{END}{$regexp} = [@meta_keys];
  }
  return \%{$self->{END}};
}

# RAS::Context->match_regexp() method
sub match_regexp {
# Desc: Checks whether or not the given data matches the given regexp.
#       Populates value of given metadata keys with regexp backrefs, if any.
# Input: 1) $  I  Data
#        2) $  I  Regexp
#        3) \@ I  Metadata hash keys to use for populating regexp backrefs
#           ** or **
#           {} I  Subroutine to run after succesfull match (can be used to set
#                 custom metadata.
#                 Note: The subroutine is given the RAS::Context object as
#                       its first argument, followed by any $1-$9 backrefs
#                       from the regexp match.
# Returns: 0: Data does not match main regexp
#          1: Data matches main regexp
#          undef: on error
  my $self = shift;
  if ($#_ != 2) {
    return undef;
  }
  my ($data, $regexp, $metakeys) = @_;

  # Interpolate all $meta references in the regexp before we try to match.
  # All special regexp characters in the metadata are escaped with a '/'
  # in order not to break the main regexp.  If the metadata being referenced
  # doesn't exist, substitute 'RAS::undef' in order to deter false matches.
  my $interp_regexp = $regexp;
  my %meta = %{$self->{METADATA}};
  $interp_regexp =~ s#\$meta{(\w+)}#
     my $meta_val = $meta{$1};
     if ($meta_val eq '') {
       $meta_val = 'RAS::undef'
     }
     else {
       $meta_val =~ s/(\\|\^|\.|\$|\||\(|\)|\[|\]|\*|\+|\?|\{|\})/\\$1/g
     }
  $meta_val
    #xeg;

  # Check for match
  if ($data =~ /$interp_regexp/) {
    if (ref($metakeys) eq 'CODE') {
      # Execute given code block
      &$metakeys($self, $1,$2,$3,$4,$5,$6,$7,$8,$9);
      return 1;
    }
    else {
    # Save any backrefs referenced by the given metadata keys
      for (my $i=0; $i <= $#$metakeys; $i++) {
	if (defined ${$i+1}) {
	  my $metadata = ${$i+1};
	  $self->{METADATA}{$$metakeys[$i]} = $metadata;
	  $debug && print "\t *** Setting metadata: $$metakeys[$i]=", $metadata, "\n";
	}
      }
      return 1;
    }
  }
  return 0;
}

# RAS::Context->match_start() method
sub match_start {
# Desc: Checks whether or not the given data matches the start regexp
#       Note: This function takes into account any TTL values and does not
#             match a completed context.
# Input: $ I  Data
# Returns: 0: Data does not match regexp
#          1: Data matches start regexp
#          undef: on error
  my $self = shift;
  if ($#_ != 0) {
    return undef;
  }

  my ($data) = @_;
  my $match = 0;

  # Check all regexps that define the start of the context
  my $start_keys = $self->{START};
  foreach my $start_regexp (@{$self->{START_ORDER}}) {
    my $action = $$start_keys{$start_regexp};
    if ($self->match_regexp($data, $start_regexp, $action)) {
      $match = 1;
      last if $self->{QUICKMATCH};
    }
  }
  if ($match) {
    $self->add_data($data);
  }
  return $match;
}

# RAS::Context->match_main() method
sub match_main {
# Desc: Checks whether or not the given data matches a main regexp
#       Note: This function takes into account any TTL values and does not
#             match a completed context.
# Input: $ I  Data
# Returns: 0: Data does not match regexp, ttl passed, or context is completed
#          1: Data matches main regexp
#          undef: on error
  my $self = shift;
  if ($#_ != 0) {
    return undef;
  }
  my ($data) = @_;
  my $match = 0;

  # Don't match completed context
  return 0 if $self->{COMPLETED};

  # Check time-to-live
  return 0 if $self->passed_ttl();

  # Check all regexps that define the main body of the context
  my $main_keys = $self->{MAIN};
  foreach my $main_regexp (@{$self->{MAIN_ORDER}}) {
    my $action = $$main_keys{$main_regexp};
    if ($self->match_regexp($data, $main_regexp, $action)) {
      $match = 1;
      last if $self->{QUICKMATCH};
    }
  }
  if ($match) {
    $self->add_data($data);
  }
  return $match;
}

# RAS::Context->match_end() method
sub match_end {
# Desc: Checks whether or not the given data matches the end regexp
#       Note: This function takes into account any TTL values and does not
#             match a completed context.
# Input: $ I  Data
# Returns: 0: Data does not match regexp, ttl passed, or context is completed
#          1: Data matches start regexp
#          undef: on error
  my $self = shift;
  if ($#_ != 0) {
    return undef;
  }
  my ($data) = @_;
  my $match = 0;

  # Don't match completed context
  return 0 if $self->{COMPLETED};

  # Check time-to-live
  return 0 if $self->passed_ttl();

  # Check all regexps that define the end of the context
  my $end_keys = $self->{END};
  foreach my $end_regexp (@{$self->{END_ORDER}}) {
    my $action = $$end_keys{$end_regexp};
    if ($self->match_regexp($data, $end_regexp, $action)) {
      $match = 1;
      $self->{COMPLETED} = 1;
      last if $self->{QUICKMATCH};
    }
  }
  if ($match) {
    $self->add_data($data);
  }
  return $match;
}

# RAS::Context->quickmatch() method
sub quickmatch {
# Desc: Get or set quickmatch flag.  If more than one main regexp is present
#       in the context, match_main will return as soon as any main regexp
#       matches when quickmatch is set.  This will make matching faster if
#       you have several main regexps.  It may be desirable to leave
#       quickmatch off if you are trying to capture specific metadata from
#       one or more of the regexps that may not be the first to match.
#       Quickmatch is also done on start and end regexps if set.
# Input: 1) $ I  0: Don't quickmatch
#                1: Quickmatch all regular expression
# Returns: $ summary text
  my $self = shift;
  if (@_) {
    $self->{QUICKMATCH} = shift;
  }
  return $self->{QUICKMATCH};
}

# RAS::Context->summarize() method
sub summarize {
# Desc: Get or set summary text to use for this context
# Input: 1) $ I?  Optional summary text
#                 Note: References to %meta variables will be interpolated
#           or
#           {} I? Optional subroutine that returns $ or \@($) (text or Array of text)
#                 Note: The subroutine is given the RAS::Context object
#                       as it's only argument.  If the summary contains multiple
#                       data items, be sure to return them as an array.
# Returns: \@($)  Array of summarized contexts
  my $self = shift;
  if (@_) {
    # Set new summarizer
    # Destroy any existing context data and turn off retain_data flag
    $self->{CONTEXT} = [];
    $self->{RETAIN_DATA} = 0;
    $self->{SUMMARY} = shift;
  }
  else {
    # Summarize context
    my $summary = $self->{SUMMARY};
    my $sum_data;
    if (ref($summary) eq 'CODE') {
      # Summarize from the given code block
      $sum_data = &$summary($self);
      if (ref($sum_data) ne 'ARRAY') {
	$sum_data = [ $sum_data ];
      }
    }
    else {
      # Summarize from (metadata interpolated) string
      my %meta = %{$self->{METADATA}};
      # Remove '\' escape characters before returning metadata
      foreach my $key (keys %meta) {
	$meta{$key} =~ s/\\([\\^.$|()[\]*+?{}])/$1/g;
      }
      # Interpolate summary string for metadata references
      $summary =~ s/(\$meta{\w+})/eval $1 ne '' ? eval $1 : 'RAS::undef'/eg;
      $sum_data = [ $summary ];
    }
    return $sum_data;
  }
}

# RAS::Context->interval_ttl() method
sub interval_ttl {
# Desc: Get ot set interval time to live in seconds
#       Note: Context is considered completed if the time between successive
#             context entries is greater than interval_ttl
# Input: 1) $ I?  Optional interval time to live
# Returns: $ interval time to live
  my $self = shift;
  if (@_) {
    $self->{INTERVAL_TTL} = shift;
  }
  return $self->{INTERVAL_TTL};
}

# RAS::Context->total_ttl() method
sub total_ttl {
# Desc: Get ot set total time to live in seconds
#       Note: Context is considered completed if the time since the first
#             context entry is greater than total_ttl
# Input: 1) $ I?  Optional total time to live
# Returns: $ total time to live
  my $self = shift;
  if (@_) {
    $self->{TOTAL_TTL} = shift;
  }
  return $self->{TOTAL_TTL};
}

# RAS::Context->passed_ttl() method
sub passed_ttl {
# Desc: Checks the time-to-live values associated with the context
# Input: None
# Returns: 0: Context has not passed its time-to-live
#          1: Context has passed its time-to-live
  my $self = shift;

  # Check time to live values
  my ($start_time, $last_time) = ($self->{START_TIME}, $self->{LAST_TIME});
  my $timestamp = time;
  if (!defined $start_time) {
    $self->{START_TIME} = $timestamp;
  }
  else {
    # Check total time to live
    my $tot_ttl = $self->{TOTAL_TTL};
    if (defined $tot_ttl && (($timestamp - $start_time) > $tot_ttl)) {
      $self->{COMPLETED} = 1;
      return 1;
    }
  }

  # Check interval time to live
  my $int_ttl = $self->{INTERVAL_TTL};
  if (defined $int_ttl && defined $last_time) {
    if (($timestamp - $last_time) > $int_ttl) {
      $self->{COMPLETED} = 1;
      return 1;
    }
  }
  return 0;
}

# RAS::Context->maxlength() method
sub maxlength {
# Desc: Get ot set maximum context length
#       Note: Context is considered completed if the number of context
#             entries is greater than maxlength
# Input: 1) $ I?  Optional context maximum length
# Returns: $ context length
  my $self = shift;
  if (@_) {
    $self->{MAXLENGTH} = shift;
  }
  return $self->{MAXLENGTH};
}

# RAS::Context->add_data() method
sub add_data {
# Desc: Add a data entry to the context (if retain_data flag is true)
# Input: 1) $ I  Data
# Returns: undef: on error
  my $self = shift;
  if ($#_ != 0) {
    return undef;
  }
  if ($self->{RETAIN_DATA}) {
    my ($data) = @_;
    push @{$self->{CONTEXT}}, $data;
  }

  # Update length and check for completion
  $self->{LENGTH}++;
  my $maxlength = $self->{MAXLENGTH};
  if (defined $maxlength) {
    if ($self->{LENGTH} >= $maxlength) {
      $self->{COMPLETED} = 1;
    }
  }

  # Update last entry timestamp
  $self->{LAST_TIME} = time;
}

# RAS::Context->get_data() method
sub get_data {
# Desc: Gets all context data entries
# Input: None
# Returns: \@($) Array of context data
  my $self = shift;
  my $data;
  my $summary;
  if (defined ($summary = $self->summarize())) {
    return $summary;
  }
  else {
    return \@{$self->{CONTEXT}};
  }
  return $data;
}

# RAS::Context->retain_data() method
sub retain_data {
# Desc: Get ot set retain_data flag (whether or not to save all context data)
# Input: 1) $ I?  Optional retain_data flag
# Returns: $ context retain_data
  my $self = shift;
  if (@_) {
    $self->{RETAIN_DATA} = shift;
  }
  return $self->{RETAIN_DATA};
}

# RAS::Context->set_metadata() method
sub set_metadata {
# Desc: Set metadata associated with given key
# Input: 1) $ I  Metadata key
#        2) $ I  Metadata value
# Returns: $  metadata value
#          undef: on error
  my $self = shift;
  if ($#_ != 1) {
    return undef;
  }
  my ($key, $value) = @_;
  $self->{METADATA}{$key} = $value;
  return $value;
}

# RAS::Context->get_metadata() method
sub get_metadata {
# Desc: Get metadata associated with given key or all metadata
#       Note: New data may be available after a call to any match_* function
# Input: 1) $ I?  Optional metadata key
# Returns: $  metadata value if Input(1) is given
#          \%  Hash with:  Key=metadata name   Value=metadata value
#          undef: on error
  my $self = shift;
  if (@_) {
    my $key = shift;
    if (exists $self->{METADATA}{$key}) {
      return $self->{METADATA}{$key};
    }
    else {
      return undef;
    }
  }
  else {
    return \%{$self->{METADATA}};
  }
}

# RAS::Context->pass_metadata() method
sub pass_metadata {
# Desc: Get ot set the flag specifying whether or not to pass context metadata
#       up to the filter object using the context
# Input: 1) $ I?  Optional pass metadata flag
# Returns: $ pass metadata flag
  my $self = shift;
  if (@_) {
    $self->{PASSMETA} = shift;
  }
  return $self->{PASSMETA};
}

# RAS::Context->completed() method
sub completed {
# Desc: Checks whether or not a the context is completed
# Input: 1) $ I?  Completed flag (0 or 1)
# Returns: 0: Context is not completed
#          1: Context is completed
#          undef: on error
  my $self = shift;
  if (@_) {
    my $flag = shift;
    if ($flag !~ /^(0|1)$/) {
      return undef;
    }
    $self->{COMPLETED} = $flag;
  }
  return $self->{COMPLETED};
}

# RAS::Context->clone() method
sub clone {
# Desc: Clones the current object into a new one
# Input: None
# Returns: $ RAS::Context object
  my $self = shift;

  # Clone all internal data structures
  my $clone = new RAS::Context();
  foreach my $regexp (keys %{$self->{START}}) {
    if (ref($self->{START}{$regexp}) eq 'CODE') {
      $clone->{START}{$regexp} = $self->{START}{$regexp};
    }
    else {
      @{$clone->{START}{$regexp}} = @{$self->{START}{$regexp}};
    }
  }
  foreach my $regexp (keys %{$self->{MAIN}}) {
    if (ref($self->{MAIN}{$regexp}) eq 'CODE') {
      $clone->{MAIN}{$regexp} = $self->{MAIN}{$regexp};
    }
    else {
      @{$clone->{MAIN}{$regexp}} = @{$self->{MAIN}{$regexp}};
    }
  }
  foreach my $regexp (keys %{$self->{END}}) {
    if (ref($self->{END}{$regexp}) eq 'CODE') {
      $clone->{END}{$regexp} = $self->{END}{$regexp};
    }
    else {
      @{$clone->{END}{$regexp}} = @{$self->{END}{$regexp}};
    }
  }
  @{$clone->{START_ORDER}} = @{$self->{START_ORDER}};
  @{$clone->{MAIN_ORDER}} = @{$self->{MAIN_ORDER}};
  @{$clone->{END_ORDER}} = @{$self->{END_ORDER}};
  $clone->{START_TIME} = $self->{START_TIME};
  $clone->{LAST_TIME} = $self->{LAST_TIME};
  $clone->{INTERVAL_TTL} = $self->{INTERVAL_TTL};
  $clone->{TOTAL_TTL} = $self->{TOTAL_TTL};
  $clone->{LENGTH} = $self->{LENGTH};
  $clone->{MAXLENGTH} = $self->{MAXLENGTH};
  $clone->{SUMMARY} = $self->{SUMMARY};
  $clone->{QUICKMATCH} = $self->{QUICKMATCH};
  $clone->{RETAIN_DATA} = $self->{RETAIN_DATA};
  $clone->{PASSMETA} = $self->{PASSMETA};
  $clone->{COMPLETED} = $self->{COMPLETED};
  @{$clone->{CONTEXT}} = @{$self->{CONTEXT}};
  foreach my $metakey (keys %{$self->{METADATA}}) {
    $clone->{METADATA}{$metakey} = $self->{METADATA}{$metakey};
  }
  return $clone;
}

# RAS::Context->reset() method
sub reset {
# Desc: Reset the context back to its base definition
# Input: None
# Returns: None
  my $self = shift;

  $self->{START_TIME} = undef;
  $self->{LAST_TIME} = undef;
  $self->{LENGTH} = 0;
  $self->{COMPLETED} = 0;
  $self->{CONTEXT} = [];
  $self->{METADATA} = {};
}

#-------- RAS::Dispatch Object --------##

package RAS::Dispatch;
use strict;
use warnings;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
             &add_handler
             &get_all_handlers
             &dispatch
	    );

sub new {
# Desc: RAS::Dispatch object constructor
# Input: None
# Returns: $  blessed object, empty
#          undef: on error
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my $self = {};
  bless($self, $class);
  if ($#_ != -1) {
    return undef;
  }

  $self->{HANDLERS} = [];

  return $self;
}

# RAS::Dispatch->add_handler() method
sub add_handler {
# Desc: Add an event filter/action pair
# Input: 1) $ I  RAS::Filter object
#        2) $ or \@ I  One or more RAS::Action objects (scalar or array ref)
#        3) $ I  RAS::Event (or subclassed) object to use for this handler
#        4) $ I? Optional continue flag: 1: continue processing other handlers
#                                           after positive match
# Returns: undef: on error
  my $self = shift;
  my ($filter, $actions, $event, $continue) = @_;

  unless (ref($actions) eq 'ARRAY') {
    $actions = [ $actions ];
  }

  $continue = 0 if !defined $continue;

  push @{$self->{HANDLERS}}, [$filter, $actions, $event, $continue];
}

# RAS::Dispatch->get_all_handlers() method
sub get_all_handlers {
# Desc: Get all event filter/action pairs
# Input: None
# Returns: \@ Array of [$ RAS::Filter object, \@ RAS::Action objects,
#                       $ RAS::Event object, $ continue flag]
  my $self = shift;

  return \@{$self->{HANDLERS}};
}

# RAS::Dispatch->dispatch() method
sub dispatch {
# Desc: Calls the main engine for dispatching events
#       Different actions can be taken depending on the event handler
# Input: 1) $ I  Input string
# Returns: Nothing
  my $self = shift;
  my $input = shift;

#  $debug && print "INPUT: $input\n";

  # Pass input through event handlers
 HANDLER1: foreach my $handler (@{$self->get_all_handlers()}) {
    my ($filter, $actions, $eventObj, $continue) = @$handler;
    my @events;
    my $filtered = $filter->filter($input);
    for (my $idx=0; $idx <= $#$filtered; $idx++) {
      my ($entry, $metadata) = @{$$filtered[$idx]};
      my $event = $eventObj->new($entry, $metadata);
      push @events, $event;
    }
    
    # Process actions for each event
    foreach my $event (@events) {
      if (defined $event) {
	foreach my $action (@$actions) {
	  $action->execute($event);
	}
      }
      else {
	print "Error creating event from message: ", $event->message(), "\n";
      }
    }
    last HANDLER1 unless $continue;
  }
}

# RAS::Dispatch->flush() method
sub flush {
# Desc: Flushes all filters, then processes the output just like dispatch()
# Input: None
# Returns: Nothing
  my $self = shift;

  $debug && print "\t *** Flushing the dispatcher\n";

  # Flush the filters of each event handler
 HANDLER2: foreach my $handler (@{$self->get_all_handlers()}) {
    my ($filter, $actions, $eventObj) = @$handler;
    my $filtered = $filter->flush();
    for (my $idx=0; $idx <= $#$filtered; $idx++) {
      my @events;
      my ($entry, $metadata) = @{$$filtered[$idx]};
      my $event = $eventObj->new($entry, $metadata);
      push @events, $event;

      # Process actions for each event
      foreach my $event (@events) {
	if (defined $event) {
	  foreach my $action (@$actions) {
	    $action->execute($event);
	  }
	}
	else {
	  print "Error creating event from message: ", $event->message(), "\n";
	}
      }
    }
  }
}


#-------- RAS::Action Object --------##

package RAS::Action;
use strict;
use warnings;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
             &type
             &add_recipient
             &run_cmd
             &execute
	    );

sub new {
# Desc: RAS::Action object constructor
# Input: Action type (one of 'echo,track,forward,runcmd,ticket,log')
# Returns: $  blessed object, empty
#          undef: on error
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my $self = {};
  bless($self, $class);
  if ($#_ != 0) {
    return undef;
  }
  my ($type) = @_;

  if (!defined ($self->type($type))) {
    return undef;
  }

  $self->{COMMS} = [];
  $self->{CMD} = undef;

  return $self;
}

# RAS::Action->type() method
sub type {
# Desc: Gets or sets Action type (echo,track,forward,runcmd,ticket,log)
# Input: 1) $ I?  Optional action type
# Returns: $  action type
#          undef: on error
  my $self = shift;
  my ($type) = @_;

  if (defined $type) {
    if ($type =~ /^(echo|track|forward|runcmd|ticket|log)$/) {
      $self->{TYPE} = $type;
    }
    else {
      return undef;
    }
  }

  return $self->{TYPE};
}

# RAS::Action->add_recipient() method
sub add_recipient {
# Desc: Adds a recipient to forward any events to for 'forward' type actions
# Input: 1) $ I  RAS::Comm object
# Returns: Nothing
#          undef: on error
  my $self = shift;
  my ($comm) = @_;
  if ($#_ != 0 || $self->{TYPE} ne 'forward') {
    return undef;
  }

  push @{$self->{COMMS}}, $comm;
}

# RAS::Action->runcmd() method
sub runcmd {
# Desc: Set a command to run for any data passed in
# Input: 1) $ I  Command to run
# Returns: $ command
  my $self = shift;
  my ($command) = @_;

  return undef unless $self->type() eq 'runcmd';

  if (defined $command) {
    $self->{CMD} = $command;
  }
  else {
    return $self->{CMD};
  }
}

# RAS::Action->execute() method
sub execute {
# Desc: executes the action for the given event
# Input: $ I  RAS::Event object
# Returns: undef: on error
  my $self = shift;
  if ($#_ != 0) {
    return undef;
  }

  my $type = $self->type();
  my $event = shift;

  if ($type eq 'echo') {
    print $event->printable() , "\n";
  }
  elsif ($type eq 'track') {
    if (!defined $event->create()) {
      print STDERR "Error creatng event: ", $event->source(), ': ', $event->message(), "\n\n";
    }
  }
  elsif ($type eq 'runcmd') {
    if (! defined $self->{CMD}) {
      print STDERR "Error: No command given\n.";
      return undef;
    }
    my $cmd = $self->{CMD};
    $debug && print "Running command: $cmd\n";
    my %meta = %{$event->get_metadata()};
    # Interpolate cmd string for metadata references
    $cmd =~ s/(\$meta{\w+})/eval $1 ne '' ? eval $1 : "$1(RAS::undef)"/eg;
    if ($cmd =~ /RAS::undef/) {
      print STDERR "Error! Uninterpolated metdata (RAS::undef) reference in cmd string\n";
      print STDERR "* * *  Aborting command: $cmd\n";
    }
    else {
      print "Running command: $cmd\n";
      system($cmd);
      if ($? >> 8) {
	warn "Warning! Command exited poorly: $cmd\n";
      }
    }
  }
  elsif ($type eq 'forward') {
    if ($#{$self->{COMMS}}) {
      print STDERR "Error: No communication path specified.";
      return undef;
    }
    foreach my $comm (@{$self->{COMMS}}) {
      $comm->send($event);
    }
  }
  elsif ($type eq 'ticket') {

  }
  elsif ($type eq 'log') {    
    system('logger', '-t', $event->source(), $event->message());
  }
}



#-------- RAS::Event Object --------##

package RAS::Event;
use strict;
use warnings;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
	     &source
             &type
             &message
             &date
             &get_metadata
             &custom_field_value
             &get_all_custom_fields
             &printable
             &create
	    );

sub new {
# Desc: RAS::Event object constructor
# Input: 1) $ I  Event type
# Returns: $  blessed object, empty
#          undef: on error
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my $self = {};
  bless($self, $class);

  if ($#_ != 0) {
    return undef;
  }
  my ($type) = @_;

  $self->{SOURCE} = undef;
  $self->{MESSAGE} = undef;
  $self->{METADATA} = {};
  $self->{DATE} = undef;
  $self->{TYPE} = undef;
  $self->{CF_VALS} = {};
  $self->{EVENT} = undef;

  if (!defined $self->type($type)) {
    return undef;
  }

  return $self;
}

# RAS::Event->source() method
sub source {
# Desc: Gets or sets Event source
# Input: 1) $ I?  Optional event source
# Returns: $  event source
#          undef: on error
  my $self = shift;
  my ($source) = @_;

  if (defined $source) {
    $self->{SOURCE} = $source;
  }
  else {
    $source = $self->{SOURCE};
  }
  return $source;
}

# RAS::Event->type() method
sub type {
# Desc: Gets or sets Event type
# Input: 1) $ I?  Optional event type
# Returns: $  event type
#          undef: on error
  my $self = shift;
  my ($type) = @_;

  if (defined $type) {
    $self->{TYPE} = $type;
  }
  else {
    $type = $self->{TYPE};
  }
  return $type;
}

# RAS::Event->message() method
sub message {
# Desc: Gets or sets Event message
# Input: 1) $ I?  Optional event message
# Returns: $  event message
#          undef: on error
  my $self = shift;
  my ($message) = @_;

  if (defined $message) {
    $self->{MESSAGE} = $message;
  }
  else {
    $message = $self->{MESSAGE};
  }
  return $message;
}

# RAS::Event->date() method
sub date {
# Desc: Gets or sets Event date
# Input: 1) $ I?  Optional event date
# Returns: $  event date
#          undef: on error
  my $self = shift;
  my ($date) = @_;

  if (defined $date) {
    $self->{DATE} = $date;
  }
  else {
    $date = $self->{DATE};
  }
  return $date;
}

# RAS::Event->get_metadata() method
sub get_metadata {
# Desc: Get metadata associated with given key or all metadata
# Input: 1) $ I?  Optional metadata key
# Returns: $  metadata value if Input(1) is given
#          \%  Hash with:  Key=metadata name   Value=metadata value
#          undef: on error
  my $self = shift;
  if (@_) {
    my $key = shift;
    if (exists $self->{METADATA}{$key}) {
      return $self->{METADATA}{$key};
    }
    else {
      return undef;
    }
  }
  else {
    return \%{$self->{METADATA}};
  }
}

# RAS::Event->printable() method
sub printable {
# Desc: Returns a printable string for the event
# Input: None
# Returns: $  printable string
#          undef: on error
  my $self = shift;
  my $string = $self->date() . '  ' . $self->source() . ': ' .
    $self->message() . "\n";
  my $cfs = $self->get_all_custom_fields();
  foreach my $cf (sort keys %$cfs) {
    $string .= "\t$cf: $$cfs{$cf}\n";
  }

  return $string;
}

# RAS::Event->custom_field_value() method
sub custom_field_value {
# Desc: Gets or sets a custom field value
# Input: 1) $ I  Custom field name
#        2) $ I? Optional custom field value
# Returns: custom field value
#          undef: on error
  my $self = shift;
  if ($#_ != 0 && $#_ != 1) {
    return undef;
  }
  my ($CFname, $value) = @_;

  if (defined $value) {
    $self->{CF_VALS}{$CFname} = $value;
  }
  else {
    $value = $self->{CF_VALS}{$CFname};
  }
  return $value;
}

# RAS::Event->get_all_custom_fields() method
sub get_all_custom_fields {
# Desc: Gets all custom fields (with data) in the event
# Input: None
# Returns: \%  hash of custom fields currently set key=CFname value=CFvalue
  my $self = shift;

  return \%{$self->{CF_VALS}};
}

# RAS::Event->create() method
sub create {
# Desc: Creates the event within Event Tracker
#       Any event data currently in the object will be added to the AT event
# Input: None
# Returns: RTx::EventTracker::Event object
#          undef: on error
  my $self = shift;

  # Initialize RT
  RAS->init_RT();

  # Create the event in AT
  my $event = RTx::EventTracker::Event->new($RT::SystemUser);
  my $type = $self->type();

  my (%CFMap, @CFargs);
  # Create mapping of CF name to CF id
  my $CFObjs = RT::CustomFields->new($RT::SystemUser);
  $CFObjs->UnLimit();
  $CFObjs->LimitToLookupType(RAS::CustomField::applies_to_lookup('Events'));
  while (my $CF = $CFObjs->Next()) {
    $CFMap{$CF->Name()} = $CF->id();
  }

  # Prepare custom fields
  my $CFs = $self->get_all_custom_fields();
  foreach my $CFname (keys %$CFs) {
    if (exists $CFMap{$CFname}) {
      push @CFargs, "CustomField-$CFMap{$CFname}", $CFs->{$CFname};
    }
    else {
      print STDERR "Warning!  Custom Field does not exist for event type '$type': $CFname\n";
    }
  }

  # Create the event
  my ($id, $err) =
    $event->Create( Source => $self->source(), Message => $self->message(),
		    Type => $type, _RecordTransaction => 0,
		    @CFargs );

  unless ($id) {
    print STDERR "Error: Event not created: $err\n";
    return undef;
  }
  ${RAS::verbose} && print "Created '$type' event: ", $event->Id(), "\n";
  return $event;
}


#-------- RAS::Comm Object --------##

package RAS::Comm;
use strict;
use warnings;
use Storable qw( thaw nfreeze );
use IO::Socket;
use IO::Select;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
             &add_destination
             &serialize
             &deserialize
             &send
             &listen
	    );

sub new {
# Desc: RAS::Comm object constructor
# Input: Destination machine or IP address, or destination:port pair
# Returns: $  blessed object, empty
#          undef: on error
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my $self = {};
  bless($self, $class);
  my ($dest) = @_;

  $self->{DEST} = undef;
  $self->{PORT} = 2006;
  $self->{SOCKET} = undef;

  if (defined $dest) {
    if ($dest =~ /(.*):(.*)/) {
      return undef if !defined $self->destination($1);
      $self->port($2);
    }
    else {
      return undef if !defined $self->destination($dest);
    }
  }

  return $self;
}

# RAS::Comm->destination() method
sub destination {
# Desc: Set the destination for the data to be sent
# Input: 1) $ I  Destination machine name/address
# Returns: $  serialized data
#          undef: on error
  my $self = shift;
  my ($dest) = @_;

  $self->{DEST} = $dest;
}

# RAS::Comm->port() method
sub port {
# Desc: Set the port to send/receive data on
# Input: 1) $ I  Port number
# Returns: $  port number
#          undef: on error
  my $self = shift;
  my ($port) = @_;

  $self->{PORT} = $port;
}

# RAS::Comm->serialize() method
sub serialize {
# Desc: serializes data
# Input: 1) $ I  Object to serialize for transmission
# Returns: $  serialized data
#          undef: on error
  my $self = shift;
  my $dataObj = shift;

  # Serialize data and escape all newline characters
  my $serialdata = Storable::nfreeze($dataObj);
  $serialdata =~ s/([%\r\n])/sprintf("%%%02X", ord($1))/ge;
  return $serialdata;
}

# RAS::Comm->deserialize() method
sub deserialize {
# Desc: deserializes data
# Input: 1) $ I  serialized data
# Returns: $  unserialized data object
#          undef: on error
  my $self = shift;
  my ($serialdata) = @_;

  # Restore all escaped newline characters and deserialize data
  $serialdata =~ s/%([0-9A-Fa-f]{2})/chr(hex($1))/ge;
  my $dataObj = Storable::thaw($serialdata);
  return $dataObj;
}

# RAS::Comm->send() method
sub send {
# Desc: send data to remote listener
# Input: 1) $ I  data object
# Returns: undef: on error
  my $self = shift;
  my $dataObj = shift;

  my $sock = $self->{SOCKET};
  if (!defined $sock) {
    # Establish connection to destination machine
    my $dest = $self->{DEST};
    my $port = $self->{PORT};
    $sock = IO::Socket::INET->new(PeerAddr => "$dest:$port" );
    if (!defined $sock) {
      $quiet || print STDERR "Error: Couldn't connect to $dest port $port\n";
      return undef ;
    }
    $self->{SOCKET} = $sock;
  }
  print $sock $self->serialize($dataObj), "\n";
}

# RAS::Comm->listen() method
sub listen {
# Desc: listen for incoming communications
# Input: 1) \{} I  Reference to callback function to run for each received
#                  data object.
# Returns: This function does not return unless there's an error.
#          undef: on error
  my $self = shift;
  my $callback = shift;
  my $sock = $self->{SOCKET};

  # Establish a listnening socket
  my $port = $self->{PORT};
  $sock = IO::Socket::INET->new(Listen => 5,
				LocalPort => $port,
			        ReuseAddr => 1
			       );
  if (!defined $sock) {
    print STDERR "Error: Couldn't establich listener on port $port\n";
    return undef ;
  }
  $self->{SOCKET} = $sock;

  my $readset = new IO::Select();
  $readset->add($sock);

  while (1) {
    # select() on all open sockets
    my ($ready) = IO::Select->select($readset, undef, undef, 0);
    foreach my $readsock (@$ready) {
      if ($readsock == $sock) {
	# accept() new connections from the main socket and add to the readset
	my $newsock = $readsock->accept();
	$readset->add($newsock);
      }
      else {
	# process data from an existing socket
	my $data = <$readsock>;
	if ($data) {
	  # Deserialize data and send it to the callback function
	  chomp $data;
	  my $dataObj = $self->deserialize($data);
	  &$callback($dataObj);
	}
	else {
	  # remove the socket from the readset and close it
	  $readset->remove($readsock);
	  close($readsock);
	}
      }
    }
  }
}

1;
__END__


=head1 NAME

RAS - Perl module interface to the routines used by RASilience programs

=head1 SYNOPSIS

  use RAS;

=head1 DESCRIPTION

This module contains functions and classes used by all RASilience scripts.

Much of the actual heavy stuff is done by these functions.
This documentation describes these functions in basic detail.

For information on using RASilience application programs, run each program
without any arguments for usage information.

=head1 -_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

=head1

=head1 RAS::Asset object methods

=head1 -_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

B<--------------------------------------------------------------------->

B<RAS::Asset-E<gt>new($name);>

B<Description:>  RAS::Asset object constructor

=over

=item B<Parameters:>

=over

=item $name   I      Asset name

=back

=item B<Return Values:>

=over

=item $  blessed object, empty

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Asset-E<gt>asset($name, $);>

B<Description:>  Gets or sets the AT::Asset object Gets or sets Asset name

=over

=item B<Parameters:>

=over

=item $name   I?     Optional AT::Asset object

=item $       I?     Optional asset name

=back

=item B<Return Values:>

=over

=item $  asset name

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Asset-E<gt>get_id($name);>

B<Description:>  Gets Asset ID from AT

=over

=item B<Parameters:>

=over

=item $name   I      asset name

=back

=item B<Return Values:>

=over

=item $  asset ID

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Asset-E<gt>description($desc);>

B<Description:>  Gets or sets Asset description

=over

=item B<Parameters:>

=over

=item $desc   I?     Optional asset description

=back

=item B<Return Values:>

=over

=item $  asset description

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Asset-E<gt>type($type);>

B<Description:>  Gets or sets Asset type

=over

=item B<Parameters:>

=over

=item $type   I?     Optional asset type

=back

=item B<Return Values:>

=over

=item $  asset type

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Asset-E<gt>status($status);>

B<Description:>  Gets or sets Asset status

=over

=item B<Parameters:>

=over

=item $status   I?     Optional asset status

=back

=item B<Return Values:>

=over

=item $  asset status

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Asset-E<gt>add_ip_interface($IF);>

B<Description:>  Adds/updates an ethernet interface to the asset

=over

=item B<Parameters:>

=over

=item $IF   I      RAS::IP_Interface object

=back

=item B<Return Values:>

=over

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Asset-E<gt>get_ip_interface($name);>

B<Description:>  Gets an ethernet interface associated with the asset

=over

=item B<Parameters:>

=over

=item $name   I      IP interface name

=back

=item B<Return Values:>

=over

=item RAS::IP_Interface object

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Asset-E<gt>get_all_ip_interfaces( );>

B<Description:>  Gets all ethernet interfaces of the asset

=item B<Return Values:>

=over

=item \@  array of RAS::IP_Interface objects

=back

B<--------------------------------------------------------------------->

B<RAS::Asset-E<gt>custom_field_value($CFname, $value);>

B<Description:>  Gets or sets a custom field value

=over

=item B<Parameters:>

=over

=item $CFname   I      Custom field name

=item $value    I?     Optional custom field value

=back

=item B<Return Values:>

=over

=item custom field value

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Asset-E<gt>get_all_custom_fields( );>

B<Description:>  Gets all custom fields (with data) in the asset

=item B<Return Values:>

=over

=item \%  hash of custom fields currently set key=CFname value=CFvalue

=back

B<--------------------------------------------------------------------->

B<RAS::Asset-E<gt>create( );>

B<Description:>  Creates the asset within Asset Tracker Any asset data currently in the object will be added to the AT asset

=item B<Return Values:>

=over

=item RTx::AssetTracker::Asset object

=item undef: on error

=back

B<--------------------------------------------------------------------->

B<RAS::Asset-E<gt>load($name);>

B<Description:>  Loads the asset from Asset Tracker NOTE: Any method calls updating data that are called *after* RAS::Asset->load() will modify the actual asset in AT

=over

=item B<Parameters:>

=over

=item $name   I?     Optional Asset name

=back

=item B<Return Values:>

=over

=item AT::Asset object

=item undef: if asset doesn't exist or on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Asset-E<gt>unload( );>

B<Description:>  Unloads the Asset Tracker asset

=item B<Return Values:>

=over

=item None

=item undef: on error

=back

=head1 -_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

=head1

=head1 RAS::AssetType object methods

=head1 -_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

B<--------------------------------------------------------------------->

B<RAS::AssetType-E<gt>new(name);>

B<Description:>  RAS::AssetType object constructor Input: $ I  Asset Type name

=over

=item B<Parameters:>

=over

=back

=item B<Return Values:>

=over

=item $  blessed object, empty

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::AssetType-E<gt>name($comp_name, $comp_desc, $, $);>

B<Description:>  Gets or sets AssetType name Gets or sets AssetType description Adds a component to the asset type

=over

=item B<Parameters:>

=over

=item $comp_name    I?     Optional asset type name

=item $comp_desc    I?     Optional asset type description

=item $             I      Component name

=item $             I?     Optional component description

=back

=item B<Return Values:>

=over

=item $  Component name

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::AssetType-E<gt>get_components( );>

B<Description:>  Gets all components of the asset type

=item B<Return Values:>

=over

=item RAS::CustomField object with components loaded as 'Combobox' values

=back

B<--------------------------------------------------------------------->

B<RAS::AssetType-E<gt>add_custom_field($CF);>

B<Description:>  Adds a custom field to the asset type

=over

=item B<Parameters:>

=over

=item $CF   I      RAS::CustomField object

=back

=item B<Return Values:>

=over

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::AssetType-E<gt>get_custom_fields( );>

B<Description:>  Gets all custom fields of the asset type

=item B<Return Values:>

=over

=item \@  array of RAS::CustomField objects

=back

B<--------------------------------------------------------------------->

B<RAS::AssetType-E<gt>create( );>

B<Description:>  Creates the asset type within Asset Tracker

=item B<Return Values:>

=over

=item 0: on success

=item 1: on error

=back

=head1 -_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

=head1

=head1 RAS::CustomField object methods

=head1 -_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

B<--------------------------------------------------------------------->

B<RAS::CustomField-E<gt>new($field_name, $applies_to, $field_type, $multiple);>

B<Description:>  RAS::CustomField object constructor

=over

=item B<Parameters:>

=over

=item $field_name    I      Custom field name

=item $applies_to    I      Applies to

=item -----------              (Tickets,Groups,Users,Assets,Events,Ticket

=item -----------              Transactions)

=item $field_type    I      CF type

=item -----------              (Select,Freeform,Text,Wikitext,Image,Binary,Combobox)

=item $multiple      I      Multiple Values: 0: custom field can have

=item ---------                only one value

=item ---------             1: custom field can have multiple values

=back

=item B<Return Values:>

=over

=item $ blessed object, empty

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::CustomField-E<gt>name($applies_to, $, $);>

B<Description:>  Gets or sets custom field name Gets or sets custom field description Gets or sets what kind of RT/AT entity the custom field applies to

=over

=item B<Parameters:>

=over

=item $applies_to   I?     Optional custom field name

=item $             I?     Optional custom field description

=item $             I?     Optional entity type custom field applies to

=item -                    can be:

=item -                       (Tickets,Groups,Users,Assets,Events,Ticket

=item -                       Transactions)

=back

=item B<Return Values:>

=over

=item $ entity type custom field applies to

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::CustomField-E<gt>applies_to_lookup($?type, $);>

B<Description:>  Gets the non-friendly RT lookup name for the applies_to name Gets or sets custom field type

=over

=item B<Parameters:>

=over

=item $?type   I      Optional applies-to name

=item $       I?     Optional custom field type

=item -              can be:

=item -                 (Select,Freeform,Text,Wikitext,Image,Binary,Combobox)

=back

=item B<Return Values:>

=over

=item $ lookup name

=item $ custom field type

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::CustomField-E<gt>add_value($value, $desc);>

B<Description:>  Adds a potential value for 'Select' or 'Combobox' type custom fields

=over

=item B<Parameters:>

=over

=item $value   I      value string

=item $desc    I?     Optional value description

=back

=item B<Return Values:>

=over

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::CustomField-E<gt>get_values( );>

B<Description:>  Gets all potential custom field values

=item B<Return Values:>

=over

=item \@  array of potential values

=back

B<--------------------------------------------------------------------->

B<RAS::CustomField-E<gt>get_value_desc($value);>

B<Description:>  Gets description for 'Select' or 'Combobox' type custom fields values

=over

=item B<Parameters:>

=over

=item $value   I      value name

=back

=item B<Return Values:>

=over

=item $ description of given value

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::CustomField-E<gt>multiple($multiple);>

B<Description:>  Gets or sets custom field 'multiple value' flag

=over

=item B<Parameters:>

=over

=item $multiple   I?     Optional 'multiple value' flag:

=item ---------          0: custom field can have only one value

=item ---------          1: custom field can have multiple values

=back

=item B<Return Values:>

=over

=item $ custom field multiple

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::CustomField-E<gt>create( );>

B<Description:>  Creates the custom field within RT Returns the corresponding RT::CustomField object

=item B<Return Values:>

=over

=item RT::CustomField object

=item $ RT::CustomField objects

=item undef: on error

=back

=head1 -_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

=head1

=head1 RAS::IP_Interface object methods

=head1 -_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

B<--------------------------------------------------------------------->

B<RAS::IP_Interface-E<gt>new($name);>

B<Description:>  RAS::IP_Interface object constructor

=over

=item B<Parameters:>

=over

=item $name   I      Interface name

=back

=item B<Return Values:>

=over

=item $ blessed object, empty

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::IP_Interface-E<gt>name($alias, $, $, $);>

B<Description:>  Gets or sets ethernet interface name Gets or sets interface's IP address Gets or sets interface's MAC address Adds an alias of the interface

=over

=item B<Parameters:>

=over

=item $alias   I?     Optional ethernet interface name

=item $        I?     Optional IP address

=item $        I?     Optional MAC address

=item $        I      RAS::IP_Interface object

=back

=item B<Return Values:>

=over

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::IP_Interface-E<gt>get_aliases( );>

B<Description:>  Gets all aliases of the interface

=item B<Return Values:>

=over

=item \@  array of RAS::IP_Interface objects

=back

B<--------------------------------------------------------------------->

B<RAS::IP_Interface-E<gt>at_ip($requestor, $asset, $);>

B<Description:>  Gets or sets RTx::AssetTracker::IP object RAS::Ticket object constructor

=over

=item B<Parameters:>

=over

=item $requestor   I?     Optional RTx::AssetTracker::IP object

=item $asset       I      Requestor

=item $            I      Asset name

=back

=item B<Return Values:>

=over

=item $  blessed object, empty

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::IP_Interface-E<gt>requestor( );>

B<Description:>  Gets or sets Ticket requestor Gets or sets Ticket asset name Gets or sets Ticket subject Gets or sets Ticket body Gets or sets Ticket's initial owner Gets or sets Ticket queue Gets or sets Ticket priority Gets or sets Ticket's maximum possible priority Gets Ticket's history Input: 1) None Creates the asset within Asset Tracker

=item B<Return Values:>

=over

=item 0: on success

=item 1: on error

=back

=head1 -_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

=head1

=head1 RAS::EventType object methods

=head1 -_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

B<--------------------------------------------------------------------->

B<RAS::EventType-E<gt>new(name);>

B<Description:>  RAS::EventType object constructor Input: $ I  Event Type name

=over

=item B<Parameters:>

=over

=back

=item B<Return Values:>

=over

=item $  blessed object, empty

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::EventType-E<gt>name($CF, $, $);>

B<Description:>  Gets or sets EventType name Gets or sets EventType description Adds a custom field to the event type

=over

=item B<Parameters:>

=over

=item $CF   I?     Optional event type name

=item $     I?     Optional event type description

=item $     I      RAS::CustomField object

=back

=item B<Return Values:>

=over

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::EventType-E<gt>get_custom_fields( );>

B<Description:>  Gets all custom fields of the event type

=item B<Return Values:>

=over

=item \@  array of RAS::CustomField objects

=back

B<--------------------------------------------------------------------->

B<RAS::EventType-E<gt>create( );>

B<Description:>  Creates the event type within Event Tracker

=item B<Return Values:>

=over

=item 0: on success

=item 1: on error

=back

=head1 -_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

=head1

=head1 RAS::Filter object methods

=head1 -_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

B<--------------------------------------------------------------------->

B<RAS::Filter-E<gt>new($type);>

B<Description:>  RAS::Filter object constructor

=over

=item B<Parameters:>

=over

=item $type   I      Filter type (one of 'line, pipe, context')

=back

=item B<Return Values:>

=over

=item $  blessed object, empty

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Filter-E<gt>type($type);>

B<Description:>  Gets or sets Filter type (one of 'line, pipe, context')

=over

=item B<Parameters:>

=over

=item $type   I?     Optional filter type

=back

=item B<Return Values:>

=over

=item $  filter type

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Filter-E<gt>whitelist($bl_RE);>

B<Description:>  Add a regular expression to the set of lines to whitelist or retreive a regular expression of all whitelisted lines

=over

=item B<Parameters:>

=over

=item $bl_RE   I      Regular expression

=back

=item B<Return Values:>

=over

=item $ regular expression of whitelisted items

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Filter-E<gt>pipe_cmd($command);>

B<Description:>  Set a command to pipe input through for 'pipe' type filters

=over

=item B<Parameters:>

=over

=item $command   I      Command (takes input on STDIN, write output to

=item --------             STDOUT)

=back

=item B<Return Values:>

=over

=item $ command

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Filter-E<gt>create_pipe( );>

B<Description:>  Fork/exec the pipe_cmd with pipes connected to its STDIN and STDOUT

=item B<Return Values:>

=over

=item undef: on error

=back

B<--------------------------------------------------------------------->

B<RAS::Filter-E<gt>write_to_pipe( );>

B<Description:>  Write to the piped command Input: $ I  Data to write to the piped command Note: Input is assumed to be line buffered. If there is no newline character, we add one here. Read from the piped command

=item B<Return Values:>

=over

=item $ output from pipe

=back

B<--------------------------------------------------------------------->

B<RAS::Filter-E<gt>passthrough($pt_RE, $filter);>

B<Description:>  Add a regular expression to pass through to a different filter Note: prefilters and postfilters are still applied

=over

=item B<Parameters:>

=over

=item $pt_RE     I      Regular expression

=item $filter    I      RAS::Filter object

=back

=item B<Return Values:>

=over

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Filter-E<gt>add_context_def($context);>

B<Description:>  Add a new context definition to the filter

=over

=item B<Parameters:>

=over

=item $context   I      RAS::Context object

=back

=item B<Return Values:>

=over

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Filter-E<gt>get_context_defs( );>

B<Description:>  Get all contexts definitions

=item B<Return Values:>

=over

=item \%  Hash:   key=context ID   value=RAS::Context object

=back

B<--------------------------------------------------------------------->

B<RAS::Filter-E<gt>add_open_context($context, $ctx_id);>

B<Description:>  Add a new open context to the filter

=over

=item B<Parameters:>

=over

=item $context   I      RAS::Context object

=item $ctx_id    I      context ID

=back

=item B<Return Values:>

=over

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Filter-E<gt>get_open_contexts( );>

B<Description:>  Get all open contexts

=item B<Return Values:>

=over

=item \%  Hash:   key=context ID   value=Array of RAS::Context objects

=back

B<--------------------------------------------------------------------->

B<RAS::Filter-E<gt>destroy_context($ctx_id, $context);>

B<Description:>  Destroy a currently open context

=over

=item B<Parameters:>

=over

=item $ctx_id     I      RAS::Context object

=item $context    I      context ID

=back

=item B<Return Values:>

=over

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Filter-E<gt>prefilter($pf_RE, $filter);>

B<Description:>  Add a regular expression to prefilter with a different filter

=over

=item B<Parameters:>

=over

=item $pf_RE     I      Regular expression

=item $filter    I      RAS::Filter object

=back

=item B<Return Values:>

=over

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Filter-E<gt>postfilter($pf_RE, $filter);>

B<Description:>  Add a regular expression to postfilter with a different filter

=over

=item B<Parameters:>

=over

=item $pf_RE     I      Regular expression

=item $filter    I      RAS::Filter object

=back

=item B<Return Values:>

=over

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Filter-E<gt>filter($data);>

B<Description:>  Does the actual filtering

=over

=item B<Parameters:>

=over

=item $data   I      Data to filter

=back

=item B<Return Values:>

=over

=item $ Filter output

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Filter-E<gt>flush( );>

B<Description:>  End all open contexts and flush their output;

=item B<Return Values:>

=over

=item $ flushed filter output

=back

=head1 -_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

=head1

=head1 RAS::Context object methods

=head1 -_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

B<--------------------------------------------------------------------->

B<RAS::Context-E<gt>new( );>

B<Description:>  RAS::Context object constructor

=item B<Return Values:>

=over

=item $  blessed object, empty

=item undef: on error

=back

B<--------------------------------------------------------------------->

B<RAS::Context-E<gt>add_start_regexp($regexp);>

B<Description:>  Set regexp that, if matched, defines the start of a context

=over

=item B<Parameters:>

=over

=item $regexp   I      regexp matching start of context 2-9) $ I?

=item -------             metadata keys for 1st-9th backreferences ** or

=item -------             (instead of Input(2-9) ** {} I? Optional

=item -------             subroutine (useful for setting custom

=item -------             metadata)

=item -------          Note: The subroutine is given the RAS::Context

=item -------             object as it's only argument.

=item -------          Note: Metadata gathered through backreferences

=item -------             can be retreived via the get_metadata() function

=item -------             after any call to match_*(), and can be

=item -------             referenced using the uninterpolated string

=item -------             '$meta{metakey}' in the regexp of any

=item -------             add_*_regexp function.

=back

=item B<Return Values:>

=over

=item \%  Hash: key=regexp  value=[metakey1, metakey2, ... , metakey9] **

=over

=item or **

=back

=item \%  Hash: key=regexp  value={} code ref

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Context-E<gt>add_main_regexp($regexp);>

B<Description:>  Add a regexp that, if matched, will add a line to the context

=over

=item B<Parameters:>

=over

=item $regexp   I      regexp to add any line to the context 2-9) $ I?

=item -------             metadata keys for 1st-9th backreferences ** or

=item -------             (instead of Input(2-9) ** {} I? Optional

=item -------             subroutine (useful for setting custom

=item -------             metadata)

=item -------          Note: The subroutine is given the RAS::Context

=item -------             object as it's only argument.

=item -------          Note: Metadata gathered through backreferences

=item -------             can be retreived via the get_metadata() function

=item -------             after any call to match_*(), and can be

=item -------             referenced using the uninterpolated string

=item -------             '$meta{metakey}' in the regexp of any

=item -------             add_*_regexp function.

=back

=item B<Return Values:>

=over

=item \%  Hash: key=regexp  value=@[metakey1, metakey2, ... , metakey9]

=over

=item ** or **

=back

=item \%  Hash: key=regexp  value={} code ref

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Context-E<gt>add_end_regexp($regexp);>

B<Description:>  Set regexp that, if matched, will end the context

=over

=item B<Parameters:>

=over

=item $regexp   I      regexp to end the context 2-9) $ I?  metadata

=item -------             keys for 1st-9th backreferences ** or (instead

=item -------             of Input(2-9) ** {} I? Optional subroutine

=item -------             (useful for setting custom metadata)

=item -------          Note: The subroutine is given the RAS::Context

=item -------             object as it's only argument.

=item -------          Note: Metadata gathered through backreferences

=item -------             can be retreived via the get_metadata() function

=item -------             after any call to match_*(), and can be

=item -------             referenced using the uninterpolated string

=item -------             '$meta{metakey}' in the regexp of any

=item -------             add_*_regexp function.

=back

=item B<Return Values:>

=over

=item \%  Hash: key=regexp  value=[metakey1, metakey2, ... , metakey9] **

=over

=item or **

=back

=item \%  Hash: key=regexp  value={} code ref

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Context-E<gt>match_regexp($data, $regexp, \@metakeys);>

B<Description:>  Checks whether or not the given data matches the given regexp. Populates value of given metadata keys with regexp backrefs, if any.

=over

=item B<Parameters:>

=over

=item $data        I      Data

=item $regexp      I      Regexp

=item \@metakeys   I      Metadata hash keys to use for populating

=item ----------             regexp backrefs ** or ** {} I  Subroutine

=item ----------             to run after succesfull match (can be used

=item ----------             to set custom metadata.

=item ----------          Note: The subroutine is given the RAS::Context

=item ----------             object as its first argument, followed by

=item ----------             any $1-$9 backrefs from the regexp match.

=back

=item B<Return Values:>

=over

=item 0: Data does not match main regexp

=item 1: Data matches main regexp

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Context-E<gt>match_start(data);>

B<Description:>  Checks whether or not the given data matches the start regexp Note: This function takes into account any TTL values and does not match a completed context. Input: $ I  Data

=over

=item B<Parameters:>

=over

=back

=item B<Return Values:>

=over

=item 0: Data does not match regexp, ttl passed, or context is completed

=item 1: Data matches start regexp

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Context-E<gt>match_main(data);>

B<Description:>  Checks whether or not the given data matches a main regexp Note: This function takes into account any TTL values and does not match a completed context. Input: $ I  Data

=over

=item B<Parameters:>

=over

=back

=item B<Return Values:>

=over

=item 0: Data does not match regexp, ttl passed, or context is completed

=item 1: Data matches main regexp

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Context-E<gt>match_end(data);>

B<Description:>  Checks whether or not the given data matches the end regexp Note: This function takes into account any TTL values and does not match a completed context. Input: $ I  Data

=over

=item B<Parameters:>

=over

=back

=item B<Return Values:>

=over

=item 0: Data does not match regexp, ttl passed, or context is completed

=item 1: Data matches start regexp

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Context-E<gt>quickmatch( );>

B<Description:>  Get or set quickmatch flag.  If more than one main regexp is present in the context, match_main will return as soon as any main regexp matches when quickmatch is set.  This will make matching faster if you have several main regexps.  It may be desirable to leave quickmatch off if you are trying to capture specific metadata from one or more of the regexps that may not be the first to match. Quickmatch is also done on start and end regexps if set. Get or set summary text to use for this context Get ot set interval time to live in seconds Note: Context is considered completed if the time between successive context entries is greater than interval_ttl Get ot set total time to live in seconds Note: Context is considered completed if the time since the first context entry is greater than total_ttl Checks the time -to-live values associated with the context

=item B<Return Values:>

=over

=item 0: Context has not passed its time-to-live

=item 1: Context has passed its time-to-live

=back

B<--------------------------------------------------------------------->

B<RAS::Context-E<gt>maxlength($data, $);>

B<Description:>  Get ot set maximum context length Note: Context is considered completed if the number of context entries is greater than maxlength Add a data entry to the context (if retain_data flag is true)

=over

=item B<Parameters:>

=over

=item $data   I?     Optional context maximum length

=item $       I      Data

=back

=item B<Return Values:>

=over

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Context-E<gt>get_data( );>

B<Description:>  Gets all context data entries

=item B<Return Values:>

=over

=item $  concatenated string of all data entries

=back

B<--------------------------------------------------------------------->

B<RAS::Context-E<gt>retain_data($key, $value, $);>

B<Description:>  Get ot set retain_data flag (whether or not to save all context data) Set metadata associated with given key

=over

=item B<Parameters:>

=over

=item $key      I?     Optional retain_data flag

=item $value    I      Metadata key

=item $         I      Metadata value

=back

=item B<Return Values:>

=over

=item $  metadata value

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Context-E<gt>get_metadata($key);>

B<Description:>  Get metadata associated with given key or all metadata Note: New data may be available after a call to any match_* function

=over

=item B<Parameters:>

=over

=item $key   I?     Metadata key

=back

=item B<Return Values:>

=over

=item $  metadata value if Input(1) is given \%  Key=metadata name

=over

=item Value=metadata value

=back

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Context-E<gt>completed($flag);>

B<Description:>  Checks whether or not a the context is completed

=over

=item B<Parameters:>

=over

=item $flag   I?     Completed flag (0 or 1)

=back

=item B<Return Values:>

=over

=item 0: Context is not completed

=item 1: Context is completed

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Context-E<gt>clone( );>

B<Description:>  Clones the current object into a new one

=item B<Return Values:>

=over

=item $ RAS::Context object

=back

B<--------------------------------------------------------------------->

B<RAS::Context-E<gt>reset( );>

B<Description:>  Reset the context back to its base definition

=item B<Return Values:>

=over

=item None

=back

=head1 -_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

=head1

=head1 RAS::Dispatch object methods

=head1 -_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

B<--------------------------------------------------------------------->

B<RAS::Dispatch-E<gt>new( );>

B<Description:>  RAS::Dispatch object constructor

=item B<Return Values:>

=over

=item $  blessed object, empty

=item undef: on error

=back

B<--------------------------------------------------------------------->

B<RAS::Dispatch-E<gt>add_handler($filter, $actions, $event, $continue);>

B<Description:>  Add an event filter/action pair

=over

=item B<Parameters:>

=over

=item $filter      I      RAS::Filter object

=item $actions     or     \@ I  One or more RAS::Action objects (scalar

=item --------               or array ref)

=item $event       I      RAS::Event (or subclassed) object to use for

=item ------                 this handler

=item $continue    I?     Optional continue flag: 1: continue processing

=item ---------              other handlers after positive match

=back

=item B<Return Values:>

=over

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Dispatch-E<gt>get_all_handlers( );>

B<Description:>  Get all event filter/action pairs

=item B<Return Values:>

=over

=item \@ Array of [$ RAS::Filter object, \@ RAS::Action objects, $

=over

=item RAS::Event object, $ continue flag]

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Dispatch-E<gt>dispatch( );>

B<Description:>  Calls the main engine for dispatching events Different actions can be taken depending on the event handler Flushes all filters, then processes the output just like dispatch()

=item B<Return Values:>

=over

=item Nothing

=item Nothing

=back

=head1 -_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

=head1

=head1 RAS::Action object methods

=head1 -_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

B<--------------------------------------------------------------------->

B<RAS::Action-E<gt>new(type);>

B<Description:>  RAS::Action object constructor Input: Action type (one of 'echo,track,forward')

=over

=item B<Parameters:>

=over

=back

=item B<Return Values:>

=over

=item $  blessed object, empty

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Action-E<gt>type($type);>

B<Description:>  Gets or sets Action type (one of 'echo,track,forward')

=over

=item B<Parameters:>

=over

=item $type   I?     Optional action type

=back

=item B<Return Values:>

=over

=item $  action type

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Action-E<gt>add_recipient($comm);>

B<Description:>  Adds a recipient to forward any events to for 'forward' type actions

=over

=item B<Parameters:>

=over

=item $comm   I      RAS::Comm object

=back

=item B<Return Values:>

=over

=item Nothing

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Action-E<gt>execute($type);>

B<Description:>  executes the action for the given event Input: $ I  RAS::Event object RAS::Event object constructor

=over

=item B<Parameters:>

=over

=item $type   I      Event type

=back

=item B<Return Values:>

=over

=item $  blessed object, empty

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Action-E<gt>source($source);>

B<Description:>  Gets or sets Event source

=over

=item B<Parameters:>

=over

=item $source   I?     Optional event source

=back

=item B<Return Values:>

=over

=item $  event source

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Action-E<gt>type($type);>

B<Description:>  Gets or sets Event type

=over

=item B<Parameters:>

=over

=item $type   I?     Optional event type

=back

=item B<Return Values:>

=over

=item $  event type

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Action-E<gt>message($message);>

B<Description:>  Gets or sets Event message

=over

=item B<Parameters:>

=over

=item $message   I?     Optional event message

=back

=item B<Return Values:>

=over

=item $  event message

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Action-E<gt>date($date);>

B<Description:>  Gets or sets Event date

=over

=item B<Parameters:>

=over

=item $date   I?     Optional event date

=back

=item B<Return Values:>

=over

=item $  event date

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Action-E<gt>printable( );>

B<Description:>  Returns a printable string for the event

=item B<Return Values:>

=over

=item $  printable string

=item undef: on error

=back

B<--------------------------------------------------------------------->

B<RAS::Action-E<gt>custom_field_value($CFname, $value);>

B<Description:>  Gets or sets a custom field value

=over

=item B<Parameters:>

=over

=item $CFname   I      Custom field name

=item $value    I?     Optional custom field value

=back

=item B<Return Values:>

=over

=item custom field value

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Action-E<gt>get_all_custom_fields( );>

B<Description:>  Gets all custom fields (with data) in the event

=item B<Return Values:>

=over

=item \%  hash of custom fields currently set key=CFname value=CFvalue

=back

=head1 -_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

=head1

=head1 RAS::Comm object methods

=head1 -_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

B<RAS::Comm-E<gt>new($dest);>

B<Description:> RAS::Comm object constructor

=over

=item B<Parameters:>

=over

=item $dest   I?     Destination machine or IP address, or destination:port pair

=back

=item B<Return Values:>

=over

=item $  blessed object, empty

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Comm-E<gt>destination($dest);>

B<Description:>  Set the destination for the data to be sent

=over

=item B<Parameters:>

=over

=item $dest   I      Destination machine name/address

=back

=item B<Return Values:>

=over

=item $  serialized data

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Comm-E<gt>port($port);>

B<Description:>  Set the port to send/receive data on

=over

=item B<Parameters:>

=over

=item $port   I      Port number

=back

=item B<Return Values:>

=over

=item $  port number

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<RAS::Comm-E<gt>serialize($serialdata, $);>

B<Description:>  serializes data deserializes data

=over

=item B<Parameters:>

=over

=item $serialdata   I      Object to serialize for transmission

=item $             I      serialized data

=back

=item B<Return Values:>

=over

=item $  serialized data

=item $  unserialized data object

=item undef: on error

=back

=back



=head1

=head1

=head1

=head1

=head1 SEE ALSO

Send any questions/requests/gripes to:
	jjengla@sandia.gov

=head1 AUTHOR

Josh England E<lt>jjengla@sandia.govE<gt>

=head1 COPYRIGHT AND LICENSE

=cut
