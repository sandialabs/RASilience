#-------- RAS::Event::syslog Object --------## -*- cperl -*-
package RAS::Event::syslog;

require Exporter;
@RAS::Event::syslog::ISA = qw(RAS::Event);
@EXPORT = qw(&new
	    );

use strict;
use warnings;

sub new {
# Desc: RAS::Event::syslog object constructor
# Input: 1) $  I   syslog message
#        2) \% I?  Optional metadata hash
# Returns: $  blessed object
#          undef: on error
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my $self = {};
  bless($self, $class);

  if (@_) {
    my ($msg, $metadata) = @_;

    if ($msg =~ /^
               (\S{3}\s+\d+\s+\d+:\d+:\d+)      # date
               \s+
               (\S+)                            # host
               \s+
               (.*)                             # message
               $/ox) {
      my ($date, $host, $message) = ($1, $2, $3);
      $host =~ s/^\w+@//;
      $host =~ s|^([^/]+)/\1|$1|;
      $self = $self->SUPER::new('syslog');
      $self->date($date);
      $self->source($host);
      $self->message($message);
      if (defined $metadata) {
	$self->{METADATA} = $metadata;
      }
    }
    else {
      print STDERR "Warning: line not in syslog format: $msg\n";
      return undef;
    }
  }

  return $self;
}

1;
