#!/usr/bin/perl
# Author: Josh England <jjengla@sandia.gov>
# This script is a simple client that sends events to a listener
#
# Copyright (2006) Josh England, Sandia Corporation.
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation,
# the U.S. Government retains certain rights in this software
#
#    This file is part of RASilience (http://rasilience.sourceforge.net).
#
#    RASilience is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    any later version.
#
#    RASilience is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with RASilience; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
###############################################################################

use RAS;

my $obj = new RAS::Event('syslog');
$obj->source('me');
$obj->message('test');

my $dest = new RAS::Comm('localhost');
while (1) {
    $dest->send($obj);
}
