=head1 NAME

  RTx::EventTracker::Event - an EventTracker Event object

=head1 SYNOPSIS

  use RTx::EventTracker::Event;

=head1 DESCRIPTION


=head1 METHODS

=begin testing 

use RTx::EventTracker::Event;

=end testing

=cut


package RTx::EventTracker::Event;

use strict;
no warnings qw(redefine);

use RTx::EventTracker::Type;
use RTx::EventTracker::Events;
use RT::CustomField;

if ($RT::VERSION gt '3.4.1' or $RT::VERSION eq '0.0.0' ) {
    RT::CustomField->_ForObjectType( 'RTx::EventTracker::Type-RTx::EventTracker::Event' => "Events" );
} else {
    $RT::CustomField::FRIENDLY_OBJECT_TYPES{'RTx::EventTracker::Type-RTx::EventTracker::Event'} = "Events";
}


# {{{ sub Load

=head2 Load

Takes a single argument. This can be a event id or
event name.  If the event can't be loaded, returns undef.
Otherwise, returns the event id.

=cut

sub Load {
    my $self = shift;
    my $id   = shift;

    #If we have an integer URI, load the event
    if ( $id =~ /^\d+$/ ) {
        my ($eventid,$msg) = $self->LoadById($id);

        unless ($self->Id) {
            $RT::Logger->crit("$self tried to load a bogus event: $id\n");
            return (undef);
        }
    }

    elsif ( $id ) {
        my ($eventid,$msg) = $self->LoadByCol('Name', $id);

        unless ($self->Id) {
            $RT::Logger->crit("$self tried to load a bogus event named: $id\n");
            return (undef);
        }
    }

    else {
        $RT::Logger->warning("Tried to load a bogus event id: '$id'");
        return (undef);
    }

    #Ok. we're loaded. lets get outa here.
    return ( $self->Id );

}

# }}}

# {{{ sub Create

=head2 Create (ARGS)

Arguments: ARGS is a hash of named parameters.  Valid parameters are:

  Source -- Source of event
  Type -- Either a Type object or a Type Name
  Message -- The message text of the event
  CustomField-<n> -- a scalar or array of values for the customfield with the id <n>


Returns: EVENTID, Error Message


=cut

sub Create {
    my $self = shift;

    my %args = (
        Source             => undef,
        Type               => undef,
        Message            => undef,
        @_
    );

    my ( $ErrStr, $Owner, $resolved );
    my (@non_fatal_errors);

    my $TypeObj = RTx::EventTracker::Type->new($RT::SystemUser);

    if ( ( defined( $args{'Type'} ) ) && ( !ref( $args{'Type'} ) ) ) {
        $TypeObj->Load( $args{'Type'} );
    }
    elsif ( ref( $args{'Type'} ) eq 'RTx::EventTracker::Type' ) {
        $TypeObj->Load( $args{'Type'}->Id );
    }
    else {
        $RT::Logger->debug( $args{'Type'} . " not a recognized type object." );
    }

    #Can't create a event without a type.
    unless (defined($TypeObj) && $TypeObj->Id) {
	$RT::Logger->debug("$self No type given for event creation.");
        return ( 0, $self->loc('Could not create event. Type not set') );
    }

#     #Now that we have a type, Check the ACLS
#     unless (
#         $self->CurrentUser->HasRight(
#             Right  => 'CreateEvent',
#             Object => $TypeObj,
#             EquivObjects => [ $RTx::EventTracker::System ],
#         )
#       )
#     {
#         return (
#             0, 0,
#             $self->loc( "No permission to create events of this type '[_1]'", $TypeObj->Name));
#     }

    $RT::Handle->BeginTransaction();

    my ($id,$msg) = $self->SUPER::Create( Source => $args{'Source'},
					  Type => $TypeObj->Id(),
					  Message => $args{'Message'}
					  );
    unless ($id) {
        $RT::Logger->crit( "Couldn't create a event: " . $msg );
        $RT::Handle->Rollback();
        return ( 0, 
            $self->loc("Event could not be created due to an internal error")
        );
    }

    # {{{ Add all the custom fields

    foreach my $arg ( keys %args ) {
        next unless ( $arg =~ /^CustomField-(\d+)$/i );
        my $cfid = $1;
        foreach
          my $value ( UNIVERSAL::isa( $args{$arg} => 'ARRAY' ) ? @{ $args{$arg} } : ( $args{$arg} ) )
        {
            next unless ( length($value) );

            # Allow passing in uploaded LargeContent etc by hash reference
            $self->_AddCustomFieldValue(
                (UNIVERSAL::isa( $value => 'HASH' )
                    ? %$value
                    : (Value => $value)
                ),
                Field             => $cfid,
                RecordTransaction => 0,
            );
        }
    }

    # }}}

    $RT::Handle->Commit();
    $ErrStr = $self->loc( "Event [_1] created of type '[_2]'", $self->Id, $TypeObj->Name );
    $ErrStr = join( "\n", $ErrStr, @non_fatal_errors );
    return ( $self->Id, $ErrStr );
}

# }}}

# {{{ sub TypeObj

=head2 TypeObj

Takes nothing. returns this event's type object

=cut

sub TypeObj {
    my $self = shift;

    my $type_obj = RTx::EventTracker::Type->new( $self->CurrentUser );

    #We call __Value so that we can avoid the ACL decision and some deep recursion
    my ($result) = $type_obj->Load( $self->__Value('Type') );
    return ($type_obj);
}

# }}}

sub CustomFieldLookupType {
    "RTx::EventTracker::Type-RTx::EventTracker::Event";
}

# for pre RT 3.4.2 compatability
sub _LookupTypes {
    "RTx::EventTracker::Type-RTx::EventTracker::Event";
}

sub SetName {

    my $self = shift;
    my %args = (
                  Value => undef,
                              @_,
              );
    return $self->_Set(Field => 'Name', Value => $args{Value});
}

sub SetMessage {
    my $self = shift;
           
    $self->_SetBasic(@_, Field => 'Message');
}

sub SetType {
    my $self = shift;
           
    $self->_SetBasic(@_, Field => 'Type');
}

sub _SetBasic {
    my $self = shift;

    my $extra_value;
    if (@_ % 2 ) {

        # odd number of arguments left. first is the value. called using old-skool one arg way (no TransactionData)
        $extra_value = shift;
        $RT::Logger->crit("Deprecated call to Set*. Event Tracker uses named parameters for Set methods");
    }

    my %args = (
           Field => undef,
           Value => undef,
                    @_,
    );
    $args{Value} = $extra_value if defined $extra_value;

    if ( $self->_Accessible( $args{Field}, 'write' ) ) {

        return ( $self->_Set( Field => $args{Field}, Value => $args{Value}) );
    }

    elsif ( $self->_Accessible( $args{Field}, 'read' ) ) {
        return ( 0, 'Immutable field' );
    }
    else {
        return ( 0, 'Nonexistant field?' );
    }


}

1;
