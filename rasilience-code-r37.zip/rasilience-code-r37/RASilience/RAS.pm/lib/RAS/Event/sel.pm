#-------- RAS::Event::sel Object --------## -*- cperl -*-
package RAS::Event::sel;

require Exporter;
@RAS::Event::sel::ISA = qw(RAS::Event);
@EXPORT = qw(&new
	    );

use strict;
use warnings;

sub new {
# Desc: RAS::Event::sel object constructor
# Input: 1) $ I?  Optional sel message
# Returns: $  blessed object
#          undef: on error
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my $self = {};
  bless($self, $class);

  if (@_) {
    my $msg = shift;
    if ($msg =~ /^
               (\w+):                          # hostname
               \s+
               (\d+)=                          # instance
               \s+
               (\d+\/\d+\/\d+\s+\d+:\d+:\d+),  # date
               \s+
               (.*)                            # message
               $/ox) {
      my ($host, $instance, $date, $message) = ($1, $2, $3, $4);
      $self = $self->SUPER::new('sel');
      $self->date($date);
      $self->source($host);
      if ($instance > 1) {
	$self->message("$message (x$instance)");
      }
      else {
	$self->message($message);
      }
    }
    elsif ($msg =~ /^
               (\w+):                    # hostname
               \s+
               (.*)                      # message
               $/ox) {
      my ($host, $message) = ($1, $2);
      $self = $self->SUPER::new('sel');
      $self->date(time);
      $self->source($host);
      $self->message($message);
    }
    else {
      print STDERR "Warning: line not in SEL log format: $msg";
      return undef;
    }
  }

  return $self;
}

1;
