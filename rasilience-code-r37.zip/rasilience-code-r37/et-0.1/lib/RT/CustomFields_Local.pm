
package RT::CustomFields;

use strict;

# {{{ sub LimitToEventType

=head2 LimitToEventType TYPEID

Takes a type id (numerical) as its only argument. Makes sure that
Scopes it pulls out apply to this type (or another that you've selected with
another call to this method

=cut

sub LimitToEventType  {
    my $self = shift;
    my $type = shift;

    $self->Limit (ALIAS => $self->_OCFAlias,
                  ENTRYAGGREGATOR => 'OR',
                  FIELD => 'ObjectId',
                  VALUE => "$type")
        if defined $type;
    $self->LimitToLookupType( 'RTx::EventTracker::Type-RTx::EventTracker::Event' );
}
# }}}

# {{{ sub LimitToGlobalOrEventType

=item LimitToGlobalOrEventType TYPEID

Limits the set of custom fields found to global custom fields or those tied to the type with ID TYPEID

=cut

sub LimitToGlobalOrEventType {
    my $self = shift;
    my $type = shift;
    $self->LimitToGlobalOrObjectId( $type );
    $self->LimitToLookupType( 'RTx::EventTracker::Type-RTx::EventTracker::Event' );
}

# }}}

# {{{ sub LimitToGlobalEvent

=head2 LimitToGlobalEvent

Makes sure that
Scopes it pulls out apply to all queues (or another that you've selected with
another call to this method or LimitToType

=cut


sub LimitToGlobalEvent  {
   my $self = shift;

  $self->Limit (ALIAS => $self->_OCFAlias,
                ENTRYAGGREGATOR => 'OR',
                FIELD => 'ObjectId',
                VALUE => 0);
  $self->LimitToLookupType( 'RTx::EventTracker::Type-RTx::EventTracker::Event' );
}
# }}}

1;
